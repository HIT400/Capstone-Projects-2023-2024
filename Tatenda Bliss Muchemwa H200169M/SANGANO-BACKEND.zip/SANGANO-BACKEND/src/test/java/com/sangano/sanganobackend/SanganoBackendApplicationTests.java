package com.sangano.sanganobackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SanganoBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}

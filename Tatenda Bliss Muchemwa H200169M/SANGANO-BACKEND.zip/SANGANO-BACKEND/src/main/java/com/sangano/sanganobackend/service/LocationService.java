package com.sangano.sanganobackend.service;

import com.sangano.sanganobackend.DTO.request.LocationDTO;
import com.sangano.sanganobackend.entity.Location;

import java.util.List;

public interface LocationService {

    LocationDTO addNewLocation(LocationDTO locationDTO);

    List<Location> getAllLocations();
    LocationDTO updateLocation(Long id, LocationDTO locationDTO);

    Long getActiveLocationsNumber();

    Long getPendingLocationsNumber();
}

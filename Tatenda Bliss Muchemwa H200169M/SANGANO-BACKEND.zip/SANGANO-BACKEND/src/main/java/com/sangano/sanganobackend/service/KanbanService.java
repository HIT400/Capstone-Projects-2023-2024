package com.sangano.sanganobackend.service;

import com.sangano.sanganobackend.DTO.request.KanbanDTO;
import com.sangano.sanganobackend.DTO.request.KanbanTaskDTO;
import com.sangano.sanganobackend.entity.Kanban;

import java.util.List;
import java.util.Optional;

public interface KanbanService {

    List<Kanban> getAllKanbanBoards();

    Optional<Kanban> getKanbanById(Long id);

    Optional<Kanban> getKanbanByTitle(String title);

    Kanban saveNewKanban(KanbanDTO kanbanDTO);

    Kanban updateKanban(Kanban oldKanban, KanbanDTO newKanbanDTO);

    void deleteKanban(Long id);

    Kanban addNewTaskToKanban(Long kanbanId, KanbanTaskDTO taskDTO);
}


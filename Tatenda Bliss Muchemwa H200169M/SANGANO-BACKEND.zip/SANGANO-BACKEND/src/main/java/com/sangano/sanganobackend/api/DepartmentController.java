package com.sangano.sanganobackend.api;

import com.sangano.sanganobackend.DTO.request.DepartmentDTO;
import com.sangano.sanganobackend.DTO.response.DepartmentResponse;
import com.sangano.sanganobackend.DTO.response.ResponseTemplate;
import com.sangano.sanganobackend.service.DepartmentService;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/sangano/department")
@RequiredArgsConstructor
@CrossOrigin
@Tag(name = "Department")
public class DepartmentController {

    private final DepartmentService departmentService;

    @PostMapping("/addNewDepartment")
    public ResponseEntity<DepartmentResponse> addNewDepartment(@RequestBody DepartmentDTO departmentDTO) {
        return ResponseEntity.ok(departmentService.addNewDepartment(departmentDTO));
    }

    @PutMapping("/updateDepartment/{departmentId}")
    public ResponseEntity<DepartmentResponse> updateDepartment(@PathVariable("departmentId") Long departmentId,
                                                               @RequestBody DepartmentDTO departmentDTO) {
        return ResponseEntity.ok(departmentService.updateDepartment(departmentId, departmentDTO));
    }

    @GetMapping("/getAllDepartments")
    public ResponseTemplate getAllDepartments() {
        return new ResponseTemplate("Data retrieved Successfully", departmentService.viewAllDepartments());
    }
}
package com.sangano.sanganobackend.repository;

import com.sangano.sanganobackend.entity.Goal;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface GoalRepository extends JpaRepository<Goal,Long> {

    @Query("""
          select t from Goal t where t.goalStatus = "COMPLETED"
""")
    List<Goal> findCompletedGoals();
}

package com.sangano.sanganobackend.entity;

import com.sangano.sanganobackend.enums.MeetingType;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.LazyCollection;
import org.hibernate.annotations.LazyCollectionOption;
import org.springframework.format.annotation.DateTimeFormat;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Set;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Entity
public class Meeting {

    @Id
    @GeneratedValue
    private  Long id;
    private String meetingTitle;
    private String meetingAgenda;
    private String meetingLocation;
    private LocalDate meetingDate;
    @DateTimeFormat(pattern = "HH:mm")
    private LocalTime meetingStartTime;
    @DateTimeFormat(pattern = "HH:mm")
    private LocalTime meetingEndTime;
    @Enumerated(EnumType.STRING)
    private MeetingType meetingType;
    @ManyToMany
    @LazyCollection(LazyCollectionOption.FALSE)
    private Set<Department> department;

    @ManyToMany
    @LazyCollection(LazyCollectionOption.FALSE)
    private Set<Guest> guests;
}

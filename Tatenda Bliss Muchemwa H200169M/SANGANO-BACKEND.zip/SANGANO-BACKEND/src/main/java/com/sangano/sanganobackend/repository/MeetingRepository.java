package com.sangano.sanganobackend.repository;

import com.sangano.sanganobackend.entity.Meeting;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface MeetingRepository extends JpaRepository<Meeting,Long> {

    Optional<Meeting> getMeetingsById(Long id);

    @Query(nativeQuery = true, value="SELECT COUNT(*) FROM meeting")
    Long getAllMeetingsTotal();

    @Query(nativeQuery = true, value = "SELECT COUNT(*) FROM meeting WHERE meeting_date < CURRENT_DATE()")
    Long getPastMeetings();

    @Query(nativeQuery = true, value = "SELECT COUNT(*) FROM meeting WHERE meeting_date > CURRENT_DATE()")
    Long getFutureMeetings();


}
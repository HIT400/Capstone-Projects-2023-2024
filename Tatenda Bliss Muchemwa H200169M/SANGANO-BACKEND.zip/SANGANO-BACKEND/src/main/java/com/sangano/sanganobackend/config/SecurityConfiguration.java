package com.sangano.sanganobackend.config;

import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.security.web.authentication.logout.LogoutHandler;


@Configuration
@EnableWebSecurity
@RequiredArgsConstructor
@EnableMethodSecurity
public class SecurityConfiguration {

    private final JwtAuthenticationFilter jwtAuthFilter;
    private final AuthenticationProvider authenticationProvider;
    private final LogoutHandler logoutHandler;

    private static final String AUTH_REGISTER = "/sangano/register";
    private static final String AUTH_LOGIN = "/sangano/authenticate";

    private static final String REPORT_URL = "/sangano/files/**";

    private static final String  GRAPH_LINK = "/butchery/getByCode/**";
    private static final String LINE_LINK = "/butchery/getTotalSoldPricePerProduct/**";
    private static final String V2DOCS = "/v2/api-docs";
    private static final String V3DOCS = "/v3/api-docs";
    private static final String V3_EXTENDED_DOCS = "/v3/api-docs/**";
    private static final String SWAGGER_RESOURCES = "/swagger-resources";
    private static final String SWAGGER_EXTENDED_RESOURCES = "/swagger-resources/**";
    private static final String CONFIGURATION_UI = "/configuration/ui";
    private static final String CONFIGURATION_SECURITY = "/configuration/security";
    private static final String SWAGGER_UI = "/swagger-ui/**";
    private static final String WEBJARS = "/webjars/**";
    private static final String SWAGGER_UI_HTML = "/swagger-ui.html";
    private static final String REPORTS_URLS = "/sangano/reports/**";


    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {

        http
                .csrf(csrf -> csrf.disable())
                .authorizeHttpRequests(auth -> auth
                                .requestMatchers(
                                        AUTH_REGISTER,
                                        AUTH_LOGIN,
                                        V2DOCS,
                                        V3_EXTENDED_DOCS,
                                        V3DOCS,
                                        SWAGGER_RESOURCES,
                                        SWAGGER_EXTENDED_RESOURCES,
                                        CONFIGURATION_SECURITY,
                                        CONFIGURATION_UI,
                                        SWAGGER_UI,
                                        SWAGGER_UI_HTML,
                                        REPORT_URL,
                                        GRAPH_LINK,
                                        LINE_LINK,
                                        WEBJARS,
                                        REPORTS_URLS,
                                        "/butchery/users/**",
                                        "/api/v1/demo-controller"
                                ).permitAll()
                                .anyRequest().authenticated()
                )
                .sessionManagement(sess -> sess.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
                .authenticationProvider(authenticationProvider)
                .addFilterBefore(jwtAuthFilter, UsernamePasswordAuthenticationFilter.class)
                .logout()
                .logoutUrl("/api/v1/auth/logout")
                .addLogoutHandler(logoutHandler)
                .logoutSuccessHandler((request, response, authentication) ->
                        SecurityContextHolder.clearContext());


        return http.build();
    }
}


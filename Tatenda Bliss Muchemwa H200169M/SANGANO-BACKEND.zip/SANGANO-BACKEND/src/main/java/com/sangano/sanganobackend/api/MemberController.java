package com.sangano.sanganobackend.api;

import com.sangano.sanganobackend.DTO.request.UserRequest;
import com.sangano.sanganobackend.DTO.response.ResponseTemplate;
import com.sangano.sanganobackend.DTO.response.UserResponse;
import com.sangano.sanganobackend.service.MemberService;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@CrossOrigin
@RestController
@RequestMapping("/sangano/member")
@RequiredArgsConstructor
@Tag(name = "Member")
public class MemberController {

    private final MemberService memberService;

    @GetMapping("/viewAllMembers")
    public ResponseTemplate viewAllMembers(){
        return  new ResponseTemplate("Members retrieved successfully",memberService.viewAllMembers());
    }

    @PreAuthorize("hasAuthority('admin:update')")
    @PutMapping("updateMember/{emailId}")
    public ResponseEntity<UserResponse> updateUser(@PathVariable("emailId") String emailId,
                                                   @RequestBody UserRequest userRequest){
        return ResponseEntity.ok(memberService.updateUser(emailId,userRequest));
    }
}
package com.sangano.sanganobackend.repository;

import com.sangano.sanganobackend.entity.Kanban;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface KanbanRepository extends JpaRepository<Kanban, Long> {


    Optional<Kanban> findByTitle(String title);
}

package com.sangano.sanganobackend.service;

import com.sangano.sanganobackend.DTO.request.KanbanTaskDTO;
import com.sangano.sanganobackend.entity.KanbanTask;

import java.util.List;
import java.util.Optional;

public interface KanbanTaskService {

    List<KanbanTask> getAllTasks();

    Optional<KanbanTask> getTaskById(Long id);

    Optional<KanbanTask> getTaskByTitle(String title);

    KanbanTask  saveNewTask(KanbanTaskDTO taskDTO);

    KanbanTask updateTask(KanbanTask oldTask, KanbanTaskDTO newTaskDTO);

    void deleteTask(KanbanTask task);
}

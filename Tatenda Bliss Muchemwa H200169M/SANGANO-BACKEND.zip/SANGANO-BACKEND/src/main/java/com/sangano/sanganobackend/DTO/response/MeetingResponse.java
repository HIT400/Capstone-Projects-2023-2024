package com.sangano.sanganobackend.DTO.response;

import com.sangano.sanganobackend.enums.MeetingType;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import org.springframework.format.annotation.DateTimeFormat;

import java.time.LocalDate;
import java.time.LocalTime;

@Getter
@Setter
@Data
@Builder
public class MeetingResponse {

    private String meetingTitle;
    private String meetingAgenda;
    private String meetingLocation;
    private LocalDate meetingDate;
    @DateTimeFormat(pattern = "HH:mm")
    private LocalTime meetingStartTime;
    @DateTimeFormat(pattern = "HH:mm")
    private LocalTime meetingEndTime;
    @Enumerated(EnumType.STRING)
    private MeetingType meetingType;
}


package com.sangano.sanganobackend.enums;

public enum MeetingType {
    VIRTUAL,
    PHYSICAL

}


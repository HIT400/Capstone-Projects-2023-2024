package com.sangano.sanganobackend.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.LazyCollection;
import org.hibernate.annotations.LazyCollectionOption;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class Kanban {

    @Id
    @GeneratedValue
    private Long id;
    private String title;

    @OneToMany(
            cascade = {CascadeType.ALL},
            fetch =  FetchType.EAGER
    )
    private List<KanbanTask> tasks;

    @OneToMany(
            cascade = {CascadeType.ALL},
            fetch =  FetchType.EAGER
    )
    private List<KanbanTask>members;

    public  void addTask(KanbanTask task){
        if(Objects.isNull(tasks)){
            tasks = new ArrayList<>();
        }
        tasks.add(task);
    }

    public  void addMember(KanbanTask member){
        if(Objects.isNull(members)){
            members = new ArrayList<>();
        }
        members.add(member);
    }
}


package com.sangano.sanganobackend.service.impl;

import com.sangano.sanganobackend.DTO.request.UserRequest;
import com.sangano.sanganobackend.DTO.response.UserResponse;
import com.sangano.sanganobackend.entity.Member;
import com.sangano.sanganobackend.repository.MemberRepository;
import com.sangano.sanganobackend.service.MemberService;
import com.sangano.sanganobackend.user.User;
import com.sangano.sanganobackend.user.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class MemberServiceImpl implements MemberService {

    private final MemberRepository memberRepository;
    private final UserRepository userRepository;
    @Override
    public List<Member> viewAllMembers() {
        return memberRepository.findAll();
    }

    @Override
    public UserResponse updateUser(String email, UserRequest userRequest) {
        Optional<User> user = userRepository.findByEmail(email);
        Optional<Member> member = memberRepository.findByEmail(email);
        if(user.isEmpty()){
            throw  new RuntimeException("User not found");
        }
        user.get().setEmail(userRequest.getEmail());
        user.get().setRole(userRequest.getRole());
        user.get().setLastName(userRequest.getLastName());
        user.get().setFirstName(userRequest.getFirstName());
        userRepository.save(user.get());

        if(member.isEmpty()){
            throw  new RuntimeException("User not found");
        }
        member.get().setEmail(userRequest.getEmail());
        member.get().setRole(userRequest.getRole());
        member.get().setLastName(userRequest.getLastName());
        member.get().setFirstName(userRequest.getFirstName());
        memberRepository.save(member.get());

        return UserResponse.builder()
                .email(userRequest.getEmail())
                .lastName(userRequest.getLastName())
                .firstName(userRequest.getFirstName())
                .role(userRequest.getRole())
                .build();
    }
}

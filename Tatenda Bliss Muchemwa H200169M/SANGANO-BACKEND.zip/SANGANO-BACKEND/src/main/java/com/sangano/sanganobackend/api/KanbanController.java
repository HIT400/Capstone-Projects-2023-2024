package com.sangano.sanganobackend.api;

import com.sangano.sanganobackend.DTO.request.KanbanDTO;
import com.sangano.sanganobackend.DTO.request.KanbanTaskDTO;
import com.sangano.sanganobackend.entity.Kanban;
import com.sangano.sanganobackend.service.KanbanService;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@RequestMapping("/sangano/kanbans")
@RequiredArgsConstructor
@CrossOrigin
@Tag(name = "Kanban")
public class KanbanController {

    private  final KanbanService kanbanService;

    @GetMapping("/getAll")
    public ResponseEntity<?> getAllKanbans(){
        try{
            return  new ResponseEntity<>(
                    kanbanService.getAllKanbanBoards(),
                    HttpStatus.OK
            );
        } catch (Exception e){
            return  errorResponse();
        }
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> getKanban(@PathVariable Long id){
        try{
            Optional<Kanban> optKanban = kanbanService.getKanbanById(id);
            if(optKanban.isPresent()){
                return  new ResponseEntity<>(
                        optKanban.get(),
                        HttpStatus.OK
                );
            }  else{
                return  noKanbanFoundResponse(id);
            }
        } catch (Exception e){
            return  errorResponse();
        }
    }

    @GetMapping("/getByTitle")
    public  ResponseEntity<?> getKanbanTitle(@RequestParam String title){
        try {
            Optional<Kanban> optKanban = kanbanService.getKanbanByTitle(title);
            if(optKanban.isPresent()){
                return  new ResponseEntity<>(
                        optKanban.get(),
                        HttpStatus.OK
                );
            } else{
                return  new ResponseEntity<>("No kanban found with a title: "+ title,HttpStatus.NOT_FOUND);
            }
        }  catch (Exception e){
            return errorResponse();
        }
    }

    @PostMapping("/addKanban")
    public  ResponseEntity<?> createKanban(@RequestBody KanbanDTO kanbanDTO){
        try{
            return new ResponseEntity<>(
                    kanbanService.saveNewKanban(kanbanDTO),
                    HttpStatus.CREATED
            );
        } catch (Exception e){
            return  errorResponse();
        }
    }

    @PutMapping("/update/{id}")
    public ResponseEntity<?> updateKanban(@PathVariable Long id, @RequestBody KanbanDTO kanbanDTO){
        try{
            Optional<Kanban> optKanban = kanbanService.getKanbanById(id);
            if(optKanban.isPresent()){
                return new ResponseEntity<>(
                        kanbanService.updateKanban(optKanban.get(), kanbanDTO),
                        HttpStatus.OK
                );
            } else{
                return  noKanbanFoundResponse(id);
            }
        } catch (Exception e){
            return errorResponse();
        }
    }

    @DeleteMapping("/deleteKanban/{id}")
    public void deleteKanban(@PathVariable Long id){
        kanbanService.deleteKanban(id);
    }

    @GetMapping("/{kanbanId}/tasks/")
    public ResponseEntity<?> getAllTasksInKanban(@PathVariable Long kanbanId){
        try{
            Optional<Kanban> optKanban = kanbanService.getKanbanById(kanbanId);
            if(optKanban.isPresent()){
                return  new ResponseEntity<>(
                        optKanban.get().getTasks(),
                        HttpStatus.OK
                );
            } else{
                return  noKanbanFoundResponse(kanbanId);
            }
        } catch (Exception e){
            return  errorResponse();
        }
    }

    @PostMapping("/{kanbanId}/tasks")
    public ResponseEntity<?> createTaskAssignedToKanban(@PathVariable Long kanbanId, @RequestBody KanbanTaskDTO taskDTO){
        try{
            return  new ResponseEntity<>(
                    kanbanService.addNewTaskToKanban(kanbanId, taskDTO),
                    HttpStatus.CREATED
            );
        } catch (Exception e){
            return  errorResponse();
        }
    }

    private ResponseEntity<String> noKanbanFoundResponse(Long id) {
        return  new ResponseEntity<>("No kanban found with the id: " + id,HttpStatus.NOT_FOUND);
    }

    private ResponseEntity<String> errorResponse() {

        return new ResponseEntity<>("Something went wrong: (", HttpStatus.INTERNAL_SERVER_ERROR);
    }
}


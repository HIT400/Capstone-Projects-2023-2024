package com.sangano.sanganobackend.service;

import com.sangano.sanganobackend.reports.ReportType;

import java.time.LocalDate;

public interface ReportService {
    byte[] generateMeetingAttReport(ReportType reportType, String name, LocalDate date, String userName);
}

package com.sangano.sanganobackend.service.impl;

import com.sangano.sanganobackend.entity.File;
import com.sangano.sanganobackend.exception.ExceptionMessage;
import com.sangano.sanganobackend.repository.MeetingRepository;
import com.sangano.sanganobackend.service.FilesStorageService;
import lombok.RequiredArgsConstructor;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.stereotype.Service;
import org.springframework.util.FileSystemUtils;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.net.MalformedURLException;
import java.nio.file.FileAlreadyExistsException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.stream.Stream;

@Service
@RequiredArgsConstructor
public class FilesStorageServiceImpl implements FilesStorageService {

    private final FileRepository fileRepository;
    private final MeetingRepository meetingRepository;

    private final Path root = Paths.get("uploads");

    @Override
    public void init() {
        try {
            Files.createDirectories(root);
        } catch (IOException e) {
            throw new RuntimeException("Could not initialize folder for upload!");
        }
    }

    @Override
    public void save(MultipartFile file, Long meetingId) {
        var meeting = meetingRepository.findById(meetingId);
        if (meeting.isEmpty())
            throw new ExceptionMessage("Meeting  with the id " + meetingId + " is not present");

        try {
            String meetingTitle = meeting.get().getMeetingTitle();
            String filename = meetingTitle + "-" + file.getOriginalFilename();
            Path filePath = this.root.resolve(filename);
            Files.copy(file.getInputStream(), filePath);
            fileRepository.save(File.builder()
                    .name(filename)
                    .meeting(meeting.get())
                    .build());
        } catch (Exception e) {
            if (e instanceof FileAlreadyExistsException) {
                throw new RuntimeException("A file of that name already exists.");
            }

            throw new RuntimeException(e.getMessage());
        }

    }

    @Override
    public Resource load(String filename) {
        try {
            Path file = root.resolve(filename);
            Resource resource = new UrlResource(file.toUri());

            if (resource.exists() || resource.isReadable()) {
                return resource;
            } else {
                throw new RuntimeException("Could not read the file!");
            }
        } catch (MalformedURLException e) {
            throw new RuntimeException("Error: " + e.getMessage());
        }
    }

    @Override
    public boolean delete(String filename) {
        try {
            Path file = root.resolve(filename);
            var fileName = fileRepository.findByName(filename);
            if (fileName.isEmpty())
                throw new ExceptionMessage("File with the name " + fileName + " does not exist");
            fileRepository.deleteById(fileName.get().getId());
            return Files.deleteIfExists(file);
        } catch (IOException e) {
            throw new RuntimeException("Error: " + e.getMessage());
        }
    }

    @Override
    public void deleteAll() {
        FileSystemUtils.deleteRecursively(root.toFile());
    }

    @Override
    public Stream<Path> loadAll() {
        try {
            return Files.walk(this.root, 1).filter(path -> !path.equals(this.root)).map(this.root::relativize);
        } catch (IOException e) {
            throw new RuntimeException("Could not load the files!");
        }
    }

}

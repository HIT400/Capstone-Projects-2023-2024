package com.sangano.sanganobackend.service;

import com.sangano.sanganobackend.DTO.request.UserRequest;
import com.sangano.sanganobackend.DTO.response.UserResponse;
import com.sangano.sanganobackend.entity.Member;

import java.util.List;

public interface MemberService {

    List<Member> viewAllMembers();
    UserResponse updateUser(String email, UserRequest userRequest);
}
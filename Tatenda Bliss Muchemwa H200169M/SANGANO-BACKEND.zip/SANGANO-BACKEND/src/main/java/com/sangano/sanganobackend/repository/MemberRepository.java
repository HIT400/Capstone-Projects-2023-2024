package com.sangano.sanganobackend.repository;

import com.sangano.sanganobackend.entity.Member;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface MemberRepository   extends JpaRepository<Member,Long> {

    Optional<Member> findByEmail(String email);

    @Query(nativeQuery = true, value = """
     SELECT * FROM member WHERE role= 'ADMIN'
""")
    List<Member> getMembersWithRoleAdmin();
}

package com.sangano.sanganobackend.service;

import com.sangano.sanganobackend.DTO.request.DepartmentDTO;
import com.sangano.sanganobackend.DTO.response.DepartmentResponse;
import com.sangano.sanganobackend.entity.Department;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.List;

public interface DepartmentService {

    DepartmentResponse addNewDepartment(@RequestBody DepartmentDTO departmentDTO);
    DepartmentResponse updateDepartment(Long id, DepartmentDTO departmentDTO);

    List<Department> viewAllDepartments();

}

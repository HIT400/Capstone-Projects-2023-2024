package com.sangano.sanganobackend.repository;

import com.sangano.sanganobackend.entity.Task;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface TaskRepository extends JpaRepository<Task,Long> {
    @Query("""
    select t from  Task t where  t.taskStatus = "COMPLETED"
""")
    List<Task> getCompletedTasks();
}

package com.sangano.sanganobackend.api;

import com.sangano.sanganobackend.DTO.response.ResponseTemplate;
import com.sangano.sanganobackend.service.FolderService;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/sangano/folder")
@RequiredArgsConstructor
@CrossOrigin
@Tag(name = "Folder")
public class FolderController {

    private final FolderService folderService;
    @GetMapping("/getAllFolders")
    public ResponseTemplate getAllFolders(){
        return  new ResponseTemplate("All folder data retrieved successfully",folderService.getAllFolders());
    }
}


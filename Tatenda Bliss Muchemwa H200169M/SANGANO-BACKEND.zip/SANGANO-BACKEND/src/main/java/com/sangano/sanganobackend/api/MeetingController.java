package com.sangano.sanganobackend.api;

import com.sangano.sanganobackend.DTO.request.MeetingDTO;
import com.sangano.sanganobackend.DTO.response.MeetingResponse;
import com.sangano.sanganobackend.DTO.response.ResponseTemplate;
import com.sangano.sanganobackend.service.MeetingService;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/sangano/meeting")
@RequiredArgsConstructor
@CrossOrigin
@Tag(name = "Meeting")
public class MeetingController {

    private final MeetingService meetingService;

    @PostMapping("/addNewMeeting")
    public ResponseEntity<MeetingResponse> addNewMeeting(@RequestBody MeetingDTO meetingDTO) {
        return ResponseEntity.ok(meetingService.addNewMeeting(meetingDTO));
    }

    @GetMapping("/getAllMeetings")
    public ResponseTemplate viewAllMeetings() {
        return new ResponseTemplate("All meeting data retrieved successfully",
                meetingService.viewAllMeetings());
    }


    @GetMapping("/allMeetingsTotalNumber")
    public Long getMeetingTotal(){
        return  meetingService.getMeetingTotals();
    }

    @GetMapping("/allPastMeetingsTotalNumber")
    public Long getPastMeetingTotal(){
        return  meetingService.getPastMeetings();
    }


}


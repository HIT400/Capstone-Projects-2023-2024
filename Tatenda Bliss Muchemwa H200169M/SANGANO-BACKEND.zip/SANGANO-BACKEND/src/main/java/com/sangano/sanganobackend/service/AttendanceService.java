package com.sangano.sanganobackend.service;

import com.sangano.sanganobackend.DTO.request.AttendantDTO;
import com.sangano.sanganobackend.entity.Attendance;

import java.util.List;

public interface AttendanceService {

    AttendantDTO addMeetingAttendanceMembers(AttendantDTO attendantDTO);

    List<Attendance> getAllAttendance();
}

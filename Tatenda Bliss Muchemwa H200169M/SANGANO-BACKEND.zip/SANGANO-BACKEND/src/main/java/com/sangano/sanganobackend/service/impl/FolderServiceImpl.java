package com.sangano.sanganobackend.service.impl;

import com.sangano.sanganobackend.entity.Folder;
import com.sangano.sanganobackend.repository.FolderRepository;
import com.sangano.sanganobackend.service.FolderService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class FolderServiceImpl implements FolderService {

    private final FolderRepository folderRepository;
    @Override
    public List<Folder> getAllFolders() {
        return folderRepository.findAll();
    }
}

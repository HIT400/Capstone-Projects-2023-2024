package com.sangano.sanganobackend.api;

import com.sangano.sanganobackend.DTO.request.GoalDTO;
import com.sangano.sanganobackend.DTO.response.GoalResponse;
import com.sangano.sanganobackend.DTO.response.ResponseTemplate;
import com.sangano.sanganobackend.service.GoalService;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/sangano/goal")
@RequiredArgsConstructor
@Tag(name = "Goal")
@CrossOrigin
public class GoalController {
    private final GoalService goalService;

    @PostMapping("/addNewGoal")
    public ResponseEntity<GoalResponse> addNewGoal(@RequestBody GoalDTO goalDTO) {
        return ResponseEntity.ok(goalService.addNewGoal(goalDTO));
    }

    @GetMapping("/getAllGoals")
    public ResponseTemplate getAllGoals() {
        return new ResponseTemplate("Data retrieved successfully", goalService.getAllGoals());
    }

    @PutMapping("/updateGoal/{goalId}")
    public ResponseEntity<GoalResponse> updateGoal(@PathVariable("goalId") Long goalId, @RequestBody GoalDTO goalDTO) {
        return ResponseEntity.ok(goalService.updateGoal(goalId, goalDTO));
    }

    @GetMapping("/getPastGoals")
    public ResponseTemplate getPastGoals(){
        return  new ResponseTemplate("Past goals retrieved successfully",goalService.pastGoals());
    }
    @GetMapping("/getPresentGoals")
    public ResponseTemplate getPresentGoals(){
        return  new ResponseTemplate("Present goals retrieved successfully",goalService.presentGoals());
    }

    @GetMapping("/getCompletedGoals")
    public ResponseTemplate completedGoals() {
        return new ResponseTemplate("Completed goals retrieved successfully",goalService.completedGoals());

    }
}

package com.sangano.sanganobackend.service;

import java.util.List;

public interface FileService {

    List<String> getFileNameByMeetingTitle(String meetingTitle);
}

package com.sangano.sanganobackend.service.impl;

import com.sangano.sanganobackend.reports.ReportType;
import com.sangano.sanganobackend.service.ReportService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import lombok.val;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;

import static com.sangano.sanganobackend.reports.JasperReportUtil.generateReport;

import java.util.*;

@Slf4j
@Service
@AllArgsConstructor
public class ReportServiceImpl implements ReportService {

    private final AttendantRepository  attendantRepository;
    @Override
    public byte[] generateMeetingAttReport(ReportType reportType, String name, LocalDate date, String userName) {
        try {
            val content = attendantRepository.getAllAttendantMembers(date, name);
            System.out.println(content);
            Map<String, Object> parameters = new HashMap<>();
            parameters.put("generatedBy", userName);
            parameters.put("reportNumber", name);
            parameters.put("dateGenerated", DateTimeFormatter.ofLocalizedDate(FormatStyle.MEDIUM).format(date));
            return generateReport(content, "meeting_report", parameters, reportType);
        } catch (Exception e) {
            e.printStackTrace();
            //log.error("Ran into an error trying to generate an Meeting report", e.getCause());
            throw new RuntimeException ("Something went wrong whilst generating your report");
        }
    }

//    private String getUsername() {
//        val principal = httpServletRequest.getUserPrincipal();
//        if (nonNull(principal)) {
//            log.debug("### Security Context Holder obtained, the holder's name is {}", principal.getName());
//            return isNull(principal.getName()) ? "SYSTEM USER":principal.getName();
//        } else
//            return "Not Authenticated";
//}

}

package com.sangano.sanganobackend.service;

import com.sangano.sanganobackend.DTO.request.GoalDTO;
import com.sangano.sanganobackend.DTO.response.GoalResponse;
import com.sangano.sanganobackend.entity.Goal;

import java.util.List;

public interface GoalService {

    GoalResponse addNewGoal(GoalDTO goalDTO);
    List<Goal> getAllGoals();
    GoalResponse updateGoal(Long id,GoalDTO goalDTO);
    List<Goal> pastGoals();
    List<Goal> presentGoals();

    List<Goal> completedGoals();
}


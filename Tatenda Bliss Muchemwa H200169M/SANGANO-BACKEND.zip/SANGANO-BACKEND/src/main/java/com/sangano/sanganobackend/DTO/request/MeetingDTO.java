package com.sangano.sanganobackend.DTO.request;

import com.sangano.sanganobackend.entity.Guest;
import com.sangano.sanganobackend.enums.MeetingType;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.ManyToMany;
import lombok.Data;
import org.hibernate.annotations.LazyCollection;
import org.hibernate.annotations.LazyCollectionOption;
import org.springframework.format.annotation.DateTimeFormat;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.HashSet;
import java.util.Set;

@Data
public class MeetingDTO {

    private String meetingTitle;
    private String meetingAgenda;
    private String meetingLocation;
    private LocalDate meetingDate;
    @DateTimeFormat(pattern = "HH:mm")
    private LocalTime meetingStartTime;
    @DateTimeFormat(pattern = "HH:mm")
    private LocalTime meetingEndTime;
    @Enumerated(EnumType.STRING)
    private MeetingType meetingType;
    @ManyToMany
    @LazyCollection(LazyCollectionOption.FALSE)
    private Set<Long> departments = new HashSet<>();
    @ManyToMany
    @LazyCollection(LazyCollectionOption.FALSE)
    private  Set<Guest> guests;
}

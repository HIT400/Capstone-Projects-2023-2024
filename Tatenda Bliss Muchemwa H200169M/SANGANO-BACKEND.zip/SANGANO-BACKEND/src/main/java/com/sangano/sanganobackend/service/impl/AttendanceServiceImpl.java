package com.sangano.sanganobackend.service.impl;

import com.sangano.sanganobackend.DTO.request.AttendantDTO;
import com.sangano.sanganobackend.entity.Attendance;
import com.sangano.sanganobackend.service.AttendanceService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

@Service
@RequiredArgsConstructor
public class AttendanceServiceImpl implements AttendanceService {

    private final AttendantRepository attendantRepository;

    @Override
    public AttendantDTO addMeetingAttendanceMembers(AttendantDTO attendantDTO) {

        var attendMemberDetails = Attendance.builder()
                .attendEmail(attendantDTO.getAttendEmail())
                .attendName(attendantDTO.getAttendName())
                .meetingName(attendantDTO.getMeetingName())
                .meetingDate(LocalDate.now())
                .joinTime(LocalTime.now())
                .build();
        attendantRepository.save(attendMemberDetails);
        return AttendantDTO.builder()
                .attendEmail(attendantDTO.getAttendEmail())
                .attendName(attendantDTO.getAttendName())
                .meetingName(attendantDTO.getMeetingName())
                .build();
    }

    @Override
    public List<Attendance> getAllAttendance() {
        return  attendantRepository.findAll();
    }
}

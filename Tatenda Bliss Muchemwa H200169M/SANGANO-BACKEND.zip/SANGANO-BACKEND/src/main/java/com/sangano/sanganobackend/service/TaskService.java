package com.sangano.sanganobackend.service;

import com.sangano.sanganobackend.DTO.request.TaskDTO;
import com.sangano.sanganobackend.DTO.response.TaskResponse;
import com.sangano.sanganobackend.entity.Task;

import java.util.List;

public interface TaskService {

    TaskResponse addNewTask(TaskDTO taskDTO);
    List<Task> getAllTasks();
    TaskResponse updateTask(Long id,TaskDTO taskDTO);
    List<Task> presentTask();
    List<Task> completedTasks();

}


package com.sangano.sanganobackend.repository;

import com.sangano.sanganobackend.entity.Location;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface LocationRepository extends JpaRepository<Location, Long> {

    @Query(nativeQuery = true,value="SELECT COUNT(*) FROM location WHERE location_type='ACTIVE'")
    Long getActiveLocationsNumber();

    @Query(nativeQuery = true,value="SELECT COUNT(*) FROM location WHERE location_type='PENDING'")
    Long getPendingLocationsNumber();
}

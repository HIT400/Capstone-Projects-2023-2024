package com.sangano.sanganobackend.service.impl;

import com.sangano.sanganobackend.DTO.request.KanbanDTO;
import com.sangano.sanganobackend.DTO.request.KanbanTaskDTO;
import com.sangano.sanganobackend.entity.Kanban;
import com.sangano.sanganobackend.entity.KanbanTask;
import com.sangano.sanganobackend.exception.ExceptionMessage;
import com.sangano.sanganobackend.repository.KanbanRepository;
import com.sangano.sanganobackend.service.KanbanService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class KanbanServiceImpl implements KanbanService {

    private final KanbanRepository kanbanRepository;
    @Override
    public List<Kanban> getAllKanbanBoards() {
        List<Kanban> kanbanList = new ArrayList<>();
        kanbanRepository.findAll().forEach(kanbanList::add);
        return kanbanList;
    }

    @Override
    public Optional<Kanban> getKanbanById(Long id) {
        return kanbanRepository.findById(id);
    }

    @Override
    public Optional<Kanban> getKanbanByTitle(String title) {
        return kanbanRepository.findByTitle(title);
    }

    @Override
    public Kanban saveNewKanban(KanbanDTO kanbanDTO) {
        return
                kanbanRepository.save(convertDTOToKanban(kanbanDTO));
    }

    @Override
    @Transactional
    public Kanban updateKanban(Kanban oldKanban, KanbanDTO newKanbanDTO) {
        oldKanban.setTitle(newKanbanDTO.getTitle());
        return kanbanRepository.save(oldKanban);
    }

    @Override
    public void deleteKanban(Long id) {
        var kanbanId = kanbanRepository.findById(id);
        if(kanbanId.isPresent()){
            kanbanRepository.deleteById(id);
        } else {
            throw  new ExceptionMessage("Kanban with the "+id + " is not found");
        }
    }

    @Override
    @Transactional
    public Kanban addNewTaskToKanban(Long kanbanId, KanbanTaskDTO taskDTO) {
        Kanban kanban = kanbanRepository.findById(kanbanId).get();
        kanban.addTask(convertDTOToTask(taskDTO));

        return kanbanRepository.save(kanban);
    }

    private KanbanTask convertDTOToTask(KanbanTaskDTO taskDTO) {

        KanbanTask task = new KanbanTask();
        task.setTitle(taskDTO.getTitle());
        task.setDescription(taskDTO.getDescription());
        task.setStatus(taskDTO.getStatus());
        task.setMember(taskDTO.getMember());
        return  task;
    }

    private Kanban convertDTOToKanban(KanbanDTO kanbanDTO){
        Kanban kanban = new Kanban();
        kanban.setTitle(kanbanDTO.getTitle());
        return  kanban;
    }
}

package com.sangano.sanganobackend.service.impl;

import com.sangano.sanganobackend.DTO.request.TaskDTO;
import com.sangano.sanganobackend.DTO.response.TaskResponse;
import com.sangano.sanganobackend.entity.Department;
import com.sangano.sanganobackend.entity.Member;
import com.sangano.sanganobackend.entity.Task;
import com.sangano.sanganobackend.exception.ExceptionMessage;
import com.sangano.sanganobackend.repository.DepartmentRepository;
import com.sangano.sanganobackend.repository.MemberRepository;
import com.sangano.sanganobackend.repository.TaskRepository;
import com.sangano.sanganobackend.service.EmailService;
import com.sangano.sanganobackend.service.TaskService;
import jakarta.mail.MessagingException;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@Service
@RequiredArgsConstructor
public class TaskServiceImpl implements TaskService {

    private final TaskRepository taskRepository;
    private final DepartmentRepository departmentRepository;
    private final MemberRepository memberRepository;
    private final EmailService emailService;
    ExecutorService executorService = Executors.newFixedThreadPool(Runtime.getRuntime().availableProcessors());
    Set<Department> departments = new HashSet<>();
    Set<Member> members = new HashSet<>();

    @Override
    public TaskResponse addNewTask(TaskDTO taskDTO) {
        extractedMember(taskDTO);
        var task = Task.builder()
                .members(members)
                .taskStatus(taskDTO.getTaskStatus())
                .description(taskDTO.getDescription())
                .endDate(taskDTO.getEndDate())
                .startDate(taskDTO.getStartDate())
                .name(taskDTO.getName())
                .build();
        taskRepository.save(task);


        members.parallelStream().forEach(member -> {
            executorService.submit(() -> {
                try {
                    emailService.sendEmail(member.getEmail(),  taskDTO.getName(), taskDTO.getName() ,taskDTO.getEndDate(), LocalTime.from(taskDTO.getStartDate()));
                } catch (MessagingException e) {
                    throw new RuntimeException(e);
                }
            });

        });


        return getTaskResponse(taskDTO);
    }

    private static TaskResponse getTaskResponse(TaskDTO taskDTO) {
        return TaskResponse.builder()
                .taskStatus(taskDTO.getTaskStatus())
                .description(taskDTO.getDescription())
                .endDate(taskDTO.getEndDate())
                .name(taskDTO.getName())
                .startDate(taskDTO.getStartDate())
                .build();
    }

    private void extractedMember(TaskDTO taskDTO) {
        members = new HashSet<>();
        for (Long id : taskDTO.getMembers()) {
            var memberId = memberRepository.findById(id);
            if (memberId.isEmpty())
                throw new ExceptionMessage("Member with the id " + memberId + " is not present");
            members.add(memberId.get());
        }
    }


    @Override
    public List<Task> getAllTasks() {
        return taskRepository.findAll();
    }

    @Override
    public TaskResponse updateTask(Long id, TaskDTO taskDTO) {
        var task = taskRepository.findById(id);
        if (task.isEmpty())
            throw new ExceptionMessage("Task with the id " + id + " is not found");
        extractedMember(taskDTO);
        task.get().setMembers(members);
        task.get().setName(taskDTO.getName());
        task.get().setDescription(taskDTO.getDescription());
        task.get().setTaskStatus(taskDTO.getTaskStatus());

        task.get().setStartDate(taskDTO.getStartDate());
        task.get().setEndDate(taskDTO.getEndDate());
        taskRepository.save(task.get());

        members.parallelStream().forEach(member -> {
            executorService.submit(() -> {
                try {
                    emailService.sendEmail(member.getEmail(), taskDTO.getName(),taskDTO.getName(), taskDTO.getEndDate(), LocalTime.from(taskDTO.getStartDate()));
                } catch (MessagingException e) {
                    throw new RuntimeException(e);
                }
            });
        });
        return getTaskResponse(taskDTO);
    }

    @Override
    public List<Task> presentTask() {
        List<Task> presentTasks = new ArrayList<>();
        var tasks = taskRepository.findAll();
        for (Task task : tasks) {
            if (task.getEndDate().isAfter(LocalDate.now()))
                presentTasks.add(task);
        }
        return presentTasks;
    }

    @Override
    public List<Task> completedTasks() {
        return taskRepository.getCompletedTasks();
    }


}

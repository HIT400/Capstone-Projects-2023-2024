package com.sangano.sanganobackend.service;

import com.sangano.sanganobackend.entity.Folder;

import java.util.List;

public interface FolderService {

    List<Folder> getAllFolders();
}

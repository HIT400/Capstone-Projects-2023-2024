package com.sangano.sanganobackend.service;

import com.sangano.sanganobackend.DTO.request.MeetingDTO;
import com.sangano.sanganobackend.DTO.response.MeetingResponse;
import com.sangano.sanganobackend.entity.Meeting;

import java.util.List;
import java.util.Optional;

public interface MeetingService {

    MeetingResponse addNewMeeting(MeetingDTO meetingDTO);

    List<Meeting> viewAllMeetings();

    MeetingResponse updateMeeting(Long id, MeetingDTO meetingDTO);

    List<Meeting> viewPastMeetings();
    List<Meeting> viewPresentMeetings();
    List<Meeting> viewMeetingsScheduledForToday();

    Optional<Meeting> getMeetingById(Long id);

    Long  getMeetingTotals();

    Long getPastMeetings();

    Long getFutureMeetings();
}

package com.sangano.sanganobackend.api;

import com.sangano.sanganobackend.DTO.request.TaskDTO;
import com.sangano.sanganobackend.DTO.response.ResponseTemplate;
import com.sangano.sanganobackend.DTO.response.TaskResponse;
import com.sangano.sanganobackend.service.TaskService;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/sangano/task")
@RequiredArgsConstructor
@CrossOrigin
@Tag(name = "Task")
public class TaskController {

    private final TaskService taskService;

    @PostMapping("/addNewTask")
    public ResponseEntity<TaskResponse> addNewTask(@RequestBody TaskDTO taskDTO) {
        return ResponseEntity.ok(taskService.addNewTask(taskDTO));
    }

    @GetMapping("/getAllTasks")
    public ResponseTemplate getAllTasks() {
        return new ResponseTemplate("Data retrieved successfully", taskService.getAllTasks());
    }

    @PutMapping("/updateTask/{taskId}")
    public ResponseEntity<TaskResponse> updateTask(@PathVariable("taskId") Long id, @RequestBody TaskDTO taskDTO) {
        return ResponseEntity.ok(taskService.updateTask(id, taskDTO));
    }

    @GetMapping("/getPresentTasks")
    public ResponseTemplate getPresentTask() {
        return new ResponseTemplate("Present tasks retrieved successfully", taskService.presentTask());
    }

    @GetMapping("/getCompletedTasks")
    public ResponseTemplate completedTasks() {
        return new ResponseTemplate("Completed tasks retrieved successfully", taskService.completedTasks());
    }

}

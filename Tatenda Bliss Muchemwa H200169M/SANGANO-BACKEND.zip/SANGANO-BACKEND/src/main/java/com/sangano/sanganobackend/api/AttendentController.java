package com.sangano.sanganobackend.api;

import com.sangano.sanganobackend.DTO.request.AttendantDTO;
import com.sangano.sanganobackend.entity.Attendance;
import com.sangano.sanganobackend.service.AttendanceService;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping("/sangano/attendance")
@CrossOrigin
@Tag(name ="Attendance Controller")
public class AttendentController {

    private final AttendanceService  attendanceService;

    @PostMapping("/addAttendance")
    public ResponseEntity<AttendantDTO> addNewAttendance(@RequestBody AttendantDTO attendantDTO){

        return  ResponseEntity.ok(attendanceService.addMeetingAttendanceMembers(attendantDTO));
    }

    @GetMapping("/attendentMembers")
    public List<Attendance> getAllMembersAttendant(){
        return  attendanceService.getAllAttendance();
    }
}

package com.sangano.sanganobackend.service.impl;

import com.sangano.sanganobackend.DTO.request.DepartmentDTO;
import com.sangano.sanganobackend.DTO.response.DepartmentResponse;
import com.sangano.sanganobackend.entity.Department;
import com.sangano.sanganobackend.entity.Member;
import com.sangano.sanganobackend.exception.ExceptionMessage;
import com.sangano.sanganobackend.repository.DepartmentRepository;
import com.sangano.sanganobackend.repository.MemberRepository;
import com.sangano.sanganobackend.service.DepartmentService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

@Service
@RequiredArgsConstructor
public class DepartmentServiceImpl implements DepartmentService {
    private final MemberRepository memberRepository;
    private final DepartmentRepository departmentRepository;
    Set<Member> members = new HashSet<>();

    @Override
    public DepartmentResponse addNewDepartment(DepartmentDTO departmentDTO) {
        extractedMember(departmentDTO);

        var department = Department.builder()
                .name(departmentDTO.getName())
                .members(members)
                .build();
        departmentRepository.save(department);
        return getDepartmentResponse(departmentDTO);
    }

    private void extractedMember(DepartmentDTO departmentDTO) {
        members = new HashSet<>();
        for (Long id : departmentDTO.getMembers()) {
            Optional<Member> getMemberById = memberRepository.findById(id);
            if (getMemberById.isEmpty()) {
                throw new ExceptionMessage("Member with the " + id + "is not found");
            }
            members.add(getMemberById.get());
        }
    }

    private static DepartmentResponse getDepartmentResponse(DepartmentDTO departmentDTO) {
        return DepartmentResponse.builder()
                .name(departmentDTO.getName())
                .build();
    }

    @Override
    public DepartmentResponse updateDepartment(Long id, DepartmentDTO departmentDTO) {

        Optional<Department> department = departmentRepository.findById(id);
        if (department.isEmpty())
            throw new ExceptionMessage("Department with the id " + id + " is not present");
        extractedMember(departmentDTO);
        department.get().setName(departmentDTO.getName());
        department.get().setMembers(members);
        departmentRepository.save(department.get());

        return getDepartmentResponse(departmentDTO);
    }

    @Override
    public List<Department> viewAllDepartments() {
        return departmentRepository.findAll();
    }
}

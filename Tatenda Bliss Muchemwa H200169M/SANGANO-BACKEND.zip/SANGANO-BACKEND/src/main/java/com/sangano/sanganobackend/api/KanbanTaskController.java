package com.sangano.sanganobackend.api;

import com.sangano.sanganobackend.DTO.request.KanbanTaskDTO;
import com.sangano.sanganobackend.entity.KanbanTask;
import com.sangano.sanganobackend.service.KanbanTaskService;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@RequestMapping("sangano/tasks")
@CrossOrigin
@Tag(name = "Kanban Task")
@RequiredArgsConstructor
public class KanbanTaskController {

    private final KanbanTaskService taskService;
    private final KanbanTaskRepository taskRepository;

    @GetMapping("/getAll")
    public ResponseEntity<?> getAllTasks(){
        try {
            return  new ResponseEntity<>(
                    taskService.getAllTasks(),
                    HttpStatus.OK
            );
        } catch (Exception e){
            return  errorResponse();
        }
    }

    @GetMapping("/getById/{id}")
    public ResponseEntity<?> getTask(@PathVariable Long id){
        try{
            Optional<KanbanTask> optTask = taskService.getTaskById(id);
            if(optTask.isPresent()){
                return  new ResponseEntity<>(
                        optTask.get(),
                        HttpStatus.OK
                );
            } else{
                return  noTaskFoundResponse(id);
            }
        } catch (Exception e){
            return  errorResponse();
        }
    }

    @GetMapping("/getByTitle")
    public ResponseEntity<?> getTaskByTitle(@RequestParam String title) {
        try {
            Optional<KanbanTask> optTask = taskService.getTaskByTitle(title);
            if (optTask.isPresent()) {
                return new ResponseEntity<>(
                        optTask.get(),
                        HttpStatus.OK
                );
            } else {
                return new ResponseEntity<>("No task found with a title: " + title, HttpStatus.NOT_FOUND);
            }
        } catch (Exception e) {
            return errorResponse();
        }
    }

    @PostMapping("/addTask")
    public ResponseEntity<?> createTask(@RequestBody KanbanTaskDTO taskDTO){
        try {
            return new ResponseEntity<>(
                    taskService.saveNewTask(taskDTO),
                    HttpStatus.CREATED
            );
        } catch ( Exception e){
            return  errorResponse();
        }
    }

    @PutMapping("/updateTask/{id}")
    public ResponseEntity<?> updateTask(@PathVariable Long id, @RequestBody KanbanTaskDTO taskDTO ) {
        try {
            Optional<KanbanTask> optTask = taskService.getTaskById(id);
            if (optTask.isPresent()) {
                return new ResponseEntity<>(
                        taskService.updateTask(optTask.get(), taskDTO),
                        HttpStatus.OK
                );
            } else {
                return noTaskFoundResponse(id);
            }
        } catch (Exception e) {
            return errorResponse();
        }
    }
    @PutMapping("/updateTaskByStatus/{title}")
    public ResponseEntity<?> updateTaskByStatus(@PathVariable String title, @RequestBody KanbanTaskDTO taskDTO){


        try{
            Optional<KanbanTask> optTask = taskRepository.findByTitle(title);
            System.out.println(optTask);
            if(optTask.isPresent()){
                return new ResponseEntity<>(
                        taskService.updateTask(optTask.get(), taskDTO),
                        HttpStatus.OK
                );
            } else {
                return new ResponseEntity<>("Task with that name not found", HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }  catch(Exception e){
            e.printStackTrace(); // Add this line to print the stack trace
            return errorResponse();
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteTask(@PathVariable Long id){
        try {
            Optional<KanbanTask> optTask = taskService.getTaskById(id);
            if(optTask.isPresent()){
                taskService.deleteTask(optTask.get());
                return new ResponseEntity<>(String.format("Task with id: %d was deleted", id), HttpStatus.OK);
            } else {
                return noTaskFoundResponse(id);
            }
        } catch (Exception e){
            return  errorResponse();
        }
    }



    private ResponseEntity<String> noTaskFoundResponse(Long id) {

        return new ResponseEntity<>("No task found with id: "+id, HttpStatus.NOT_FOUND);
    }

    private ResponseEntity<String> errorResponse() {

        return new ResponseEntity<>("Something went wrong :(", HttpStatus.INTERNAL_SERVER_ERROR);
    }



}

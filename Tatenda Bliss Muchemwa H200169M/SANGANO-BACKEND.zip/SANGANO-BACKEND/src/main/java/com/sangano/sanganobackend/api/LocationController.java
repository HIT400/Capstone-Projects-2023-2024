package com.sangano.sanganobackend.api;

import com.sangano.sanganobackend.DTO.request.LocationDTO;
import com.sangano.sanganobackend.entity.Location;
import com.sangano.sanganobackend.service.LocationService;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/sangano/location")
@RequiredArgsConstructor
@Tag(name = "Locations")
public class LocationController {

    private final LocationService locationService;

    @PostMapping("/addNewLocation")
    public ResponseEntity<LocationDTO> addNewLocation(@RequestBody LocationDTO locationDTO){

        return  ResponseEntity.ok(locationService.addNewLocation(locationDTO));
    }

    @GetMapping("/getAllLocations")
    public List<Location> getAllLocations(){
        return  locationService.getAllLocations();
    }

    @GetMapping("/getActiveLocationsNumber")
    public Long getActiveLocationsNumber(){
        return locationService.getActiveLocationsNumber();
    }

    @GetMapping("/getPendingOrganisations")
    public Long getPendingOrganisations(){
        return  locationService.getPendingLocationsNumber();
    }


    @PutMapping("/updateLocation/{locationId}")
    public ResponseEntity<LocationDTO> updateLocation(@PathVariable("locationId") Long locationId,
                                                      @RequestBody LocationDTO locationDTO){
        return ResponseEntity.ok(locationService.updateLocation(locationId,locationDTO));
    }


}

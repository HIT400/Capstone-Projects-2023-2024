package com.sangano.sanganobackend.service.impl;

import com.sangano.sanganobackend.DTO.request.LocationDTO;
import com.sangano.sanganobackend.entity.Location;
import com.sangano.sanganobackend.exception.ExceptionMessage;
import com.sangano.sanganobackend.repository.LocationRepository;
import com.sangano.sanganobackend.service.LocationService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class LocationServiceImpl implements LocationService {

    private final LocationRepository locationRepository;

    @Override
    public LocationDTO addNewLocation(LocationDTO locationDTO) {

        var location = Location.builder()
                .name(locationDTO.getName())
                .latitude(locationDTO.getLatitude())
                .longitude(locationDTO.getLongitude())
                .locationType(locationDTO.getLocationType())
                .build();

        locationRepository.save(location);
        return LocationDTO.builder()
                .name(locationDTO.getName())
                .build();
    }

    @Override
    public List<Location> getAllLocations() {
        return locationRepository.findAll();
    }

    @Override
    public LocationDTO updateLocation(Long id, LocationDTO locationDTO) {

        Optional<Location> location = locationRepository.findById(id);
        if(location.isPresent()){
            location.get().setName(locationDTO.getName());
            location.get().setLatitude(locationDTO.getLatitude());
            location.get().setLongitude(locationDTO.getLongitude());
            location.get().setLocationType(locationDTO.getLocationType());

            locationRepository.save(location.get());
        }
        else {
            throw  new ExceptionMessage(("Id not found"));
        }
        return LocationDTO.builder()
                .build();
    }

    @Override
    public Long getActiveLocationsNumber() {
        return locationRepository.getActiveLocationsNumber();
    }

    @Override
    public Long getPendingLocationsNumber() {
        return locationRepository.getPendingLocationsNumber();
    }
}

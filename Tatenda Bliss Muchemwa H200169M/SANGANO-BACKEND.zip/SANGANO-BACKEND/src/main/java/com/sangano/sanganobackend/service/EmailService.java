package com.sangano.sanganobackend.service;

import jakarta.mail.MessagingException;

import java.time.LocalDate;
import java.time.LocalTime;

public interface EmailService {
    void sendEmail(String toEmail, String subject, String body, LocalDate meetingStartDate,
                   LocalTime meetingStartTime) throws MessagingException;
}


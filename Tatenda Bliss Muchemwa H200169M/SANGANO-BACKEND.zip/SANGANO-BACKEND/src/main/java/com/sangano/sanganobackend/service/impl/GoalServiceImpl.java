package com.sangano.sanganobackend.service.impl;

import com.sangano.sanganobackend.DTO.request.GoalDTO;
import com.sangano.sanganobackend.DTO.response.GoalResponse;
import com.sangano.sanganobackend.entity.Goal;
import com.sangano.sanganobackend.entity.Meeting;
import com.sangano.sanganobackend.exception.ExceptionMessage;
import com.sangano.sanganobackend.repository.GoalRepository;
import com.sangano.sanganobackend.repository.MeetingRepository;
import com.sangano.sanganobackend.service.GoalService;
import jakarta.validation.constraints.NotNull;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.*;

@Service
@RequiredArgsConstructor
public class GoalServiceImpl implements GoalService {

    private final GoalRepository goalRepository;
    private final MeetingRepository meetingRepository;
    Set<Meeting> meetings = new HashSet<>();
    Set<Meeting> updatedMeeting = new HashSet<>();


    @Override
    public GoalResponse addNewGoal(GoalDTO goalDTO) {
        for (Long id : goalDTO.getMeetings()) {
            Optional<Meeting> getMeetingById = meetingRepository.findById(id);
            if (getMeetingById.isEmpty())
                throw new ExceptionMessage("Meeting with the id " + id + " is not found");
            meetings.add(getMeetingById.get());
        }
        var goal = Goal.builder()
                .goalStatus(goalDTO.getGoalStatus())
                .endDate(goalDTO.getEndDate())
                .startDate(goalDTO.getStartDate())
                .name(goalDTO.getName())
                .meetings(meetings)
                .build();
        goalRepository.save(goal);
        return getGoalResponse(goalDTO);
    }

    private static GoalResponse getGoalResponse(@NotNull GoalDTO goalDTO) {
        return GoalResponse.builder()
                .goalStatus(goalDTO.getGoalStatus())
                .name(goalDTO.getName())
                .endDate(goalDTO.getEndDate())
                .startDate(goalDTO.getStartDate())
                .build();
    }

    @Override
    public List<Goal> getAllGoals() {
        return goalRepository.findAll();
    }

    @Override
    public GoalResponse updateGoal(Long id, GoalDTO goalDTO) {
        var goal = goalRepository.findById(id);
        if (goal.isEmpty())
            throw new ExceptionMessage("Goal with the id " + id + " is not found");
        for (Long meetingId : goalDTO.getMeetings()) {
            var getMeetingById = meetingRepository.findById(meetingId);
            if (getMeetingById.isEmpty())
                throw new ExceptionMessage("Goal with the the id " + meetingId + " is not present");
            updatedMeeting.add(getMeetingById.get());
        }
        goal.get().setGoalStatus(goalDTO.getGoalStatus());
        goal.get().setName(goalDTO.getName());
        goal.get().setEndDate(goalDTO.getEndDate());
        goal.get().setStartDate(goalDTO.getStartDate());
        goal.get().setMeetings(updatedMeeting);
        goalRepository.save(goal.get());


        return getGoalResponse(goalDTO);
    }

    @Override
    public List<Goal> pastGoals() {
        List<Goal> pastGoals = new ArrayList<>();
        var goals = goalRepository.findAll();
        for (Goal goal : goals) {
            if (goal.getEndDate().isBefore(LocalDate.now())) {
                pastGoals.add(goal);
            }
        }
        return pastGoals;
    }
    @Override
    public List<Goal> presentGoals() {
        List<Goal> presentGoals = new ArrayList<>();
        var goals = goalRepository.findAll();
        for (Goal goal : goals) {
            if (goal.getEndDate().isEqual(LocalDate.now()) || goal.getEndDate().isAfter(LocalDate.now()))
                presentGoals.add(goal);
        }
        return presentGoals;
    }
    @Override
    public List<Goal> completedGoals() {
        var completedGoals = goalRepository.findCompletedGoals();
        return completedGoals;
    }
}

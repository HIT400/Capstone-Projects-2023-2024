<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body style="background-color:grey"> 
    <table align="center" border="0" cellpadding="0" cellspacing="0"
           width="550" bgcolor="white" style="border:2px solid black"> 
        <tbody> 
            <tr> 
                <td align="center"> 
                    <table align="center" border="0" cellpadding="0"
                           cellspacing="0" class="col-550" width="550"> 
                        <tbody> 
                            <tr> 
                                <td align="center" style="background-color: #294be0; 
                                           height: 50px;"> 
   
                                    <a href="#" style="text-decoration: none;"> 
                                        <p style="color:white; 
                                                  font-weight:bold;"> 
                                            SANGANO BOARD 
                                        </p> 
                                    </a> 
                                </td> 
                            </tr> 
                        </tbody> 
                    </table> 
                </td> 
            </tr> 
            <tr style="height: 50px;"> 
                <td align="center" style="border: none; 
                           border-bottom: 2px solid #122ee2;  
                           padding-right: 20px;padding-left:20px"> 
                         <img src="https://sangano.s3.amazonaws.com/s1.png" height="40px">
                </td> 
            </tr> 
   
            <tr style="display: inline-block;"> 
                <td style="height: 150px; 
                           padding: 20px; 
                           border: none;  
                           border-bottom: 2px solid #361B0E; 
                           background-color: white;"> 

                    <h2 style="text-align: left; 
                               align-items: center;"> 
                        You are invited to a meeting  
                   </h2>
                   <span><span style="font-size: 20px; font-family: Cambria, Cochin, Georgia, Times, 'Times New Roman', serif;">Meeting title:</span>  <span>${body}</span>
                   <br>
                   <br>
                      <span><span style="font-size: 20px; font-family: Cambria, Cochin, Georgia, Times, 'Times New Roman', serif;">Meeting Code:</span>  <span>${roomCode}</span>
                   <br>
                   <br>
                   <span><span  style="font-size: 20px; font-family: Cambria, Cochin, Georgia, Times, 'Times New Roman', serif;">Meeting date:</span> <span>${meetingDate}</span>
                   <br>
                   <br>

                   <span><span  style="font-size: 20px; font-family: Cambria, Cochin, Georgia, Times, 'Times New Roman', serif;">Meeting Start Time:</span>  <span>${meetingStartTime}</span>
                   <br>
                   <br>
                        <span><span  style="font-size: 20px; font-family: Cambria, Cochin, Georgia, Times, 'Times New Roman', serif;">Meeting Location: </span> <span>${meetingLocation}</span>
                   <br>
                   <br>
                </td> 
            </tr> 
<tr> 
<td style="font-family:'Open Sans', Arial, sans-serif; 
           font-size:11px; line-height:18px;  
           color:#999999;"  
    valign="top"
    align="center"> 
                  © 2024 SANGANO BOARD. All Rights Reserved.<br> 
            </td> 
              </tr> 
            </tbody></table></td> 
        </tr> 
        <tr> 
          <td class="em_hide"
          style="line-height:1px; 
                 min-width:700px; 
                 background-color:#ffffff;"> 
              <img alt="" 
              src="images/spacer.gif" 
              style="max-height:1px;  
              min-height:1px;  
              display:block;  
              width:700px;  
              min-width:700px;"  
              width="700"
              border="0" 
              height="1"> 
              </td> 
        </tr> 
        </tbody> 
    </table> 
</body> 
</html>
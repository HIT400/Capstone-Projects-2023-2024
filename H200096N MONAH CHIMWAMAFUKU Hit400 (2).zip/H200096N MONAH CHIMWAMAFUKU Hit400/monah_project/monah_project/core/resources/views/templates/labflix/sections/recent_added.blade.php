<section class="pb-80 section" data-section="top">
      <div class="container-fluid">
        <div class="row">
          <div class="col-lg-12">
            <div class="section-header">
              <h2 class="section-title">@lang('Latest Items')</h2>
            </div>
          </div>
        </div><!-- row end -->
        <div class="row mb-none-30">
          @foreach($recent_added as $recent)
          <div class="col-xxl-2 col-md-3 col-4 col-xs-6 mb-30">
            <div class="movie-card  @if($recent->item_type == 1 && $recent->version == 1 || $recent->item_type == 2) paid @endif " @if($recent->item_type == 1 && $recent->version == 0) data-text="@lang('Free')" @elseif($recent->item_type == 3) data-text="@lang('Trailer')" @endif>
              <div class="movie-card__thumb thumb__2">

                <img src="{{ getImage(getFilePath('item_portrait').'/'.$recent->image->portrait) }}" alt="image">
                <a href="{{ route('watch',$recent->id) }}" class="icon"><i class="fas fa-play"></i></a>
              </div>
            </div><!-- movie-card end -->
          </div>
          @endforeach
        </div>
      </div>
    </section>
    <div class="ad-section pb-80">
      <div class="container">
        <div class="row justify-content-center">
          <div class="col-lg-8">
            @php echo showAd(); @endphp
          </div>
        </div>
      </div>
    </div>

<section class="trailer-section pb-80 bg-overlay-black bg_img section" data-section="latest_trailer" style="background: url('<?php echo e(getImage(getFilePath('item_landscape').'/'.@$single[1]->image->landscape)); ?>')">
    <div class="trailer-overlay"></div>
    <div class="container">
        <div class="row justify-content-center align-items-center mb-30-none">
            <div class="col-xl-6 col-lg-6 mb-30">
                <div class="trailer-content">
                    <h1 class="title text-white"><?php echo e(__(@$single[1]->title)); ?></h1>
                    <p><?php echo e(__(@$single[1]->preview_text)); ?></p>
                    <div class="trailer-btn">
                        <?php if(@$single[1]->item_type == 3): ?>
                            <a href="<?php echo e(route('watch', @$single[1]->id??0)); ?>" class="btn--base"><?php echo app('translator')->get('Watch Trailer'); ?></a>
                        <?php else: ?>
                            <a href="<?php echo e(route('watch', @$single[1]->id??0)); ?>" class="btn--base"><?php echo app('translator')->get('Watch Now'); ?></a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="col-xl-6 col-lg-6 mb-30">
                <div class="trailer-video-wrapper">
                    <div class="trailer-thumb">
                        <img src="<?php echo e(getImage(getFilePath('item_landscape').'/'.@$single[1]->image->landscape)); ?>" alt="trailer">
                        <div class="trailer-thumb-overlay">
                            <a class="video-icon" data-rel="lightcase:myCollection" href="<?php echo e(route('watch', @$single[1]->id??0)); ?>">
                                <i class="fas fa-play"></i>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section><?php /**PATH /home/sites/31b/a/a24bf68be6/public_html/monah_project/core/resources/views/templates/basic/sections/single2.blade.php ENDPATH**/ ?>
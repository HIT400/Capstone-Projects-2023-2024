
<?php $__env->startSection('content'); ?>
<section class="pt-120 pb-80">
    <div class="container">
        <div class="d-flex justify-content-center">
            <div class="verification-code-wrapper">
                <div class="verification-area">
                    <h5 class="pb-3 text-center"><?php echo app('translator')->get('Verify Email Address'); ?></h5>
                    <form action="<?php echo e(route('user.verify.email')); ?>" method="POST" class="submit-form">
                        <?php echo csrf_field(); ?>
                        <p class="verification-text py-3"><?php echo app('translator')->get('A 6 digit verification code sent to your email address'); ?>:  <?php echo e(showEmailAddress(auth()->user()->email)); ?></p>
    
                        <?php echo $__env->make($activeTemplate.'partials.verification_code', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
                        <div class="my-3">
                            <button type="submit" class="cmn-btn w-100"><?php echo app('translator')->get('Submit'); ?></button>
                        </div>
    
                        <div>
                            <p>
                                <?php echo app('translator')->get('If you don\'t get any code'); ?>, <a href="<?php echo e(route('user.send.verify.code', 'email')); ?>" class="base--color"> <?php echo app('translator')->get('Try again'); ?></a>
                            </p>
    
                            <?php if($errors->has('resend')): ?>
                                <small class="text-danger d-block"><?php echo e($errors->first('resend')); ?></small>
                            <?php endif; ?>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make($activeTemplate .'layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/sites/31b/a/a24bf68be6/public_html/monah_project/core/resources/views/templates/labflix/user/auth/authorization/email.blade.php ENDPATH**/ ?>
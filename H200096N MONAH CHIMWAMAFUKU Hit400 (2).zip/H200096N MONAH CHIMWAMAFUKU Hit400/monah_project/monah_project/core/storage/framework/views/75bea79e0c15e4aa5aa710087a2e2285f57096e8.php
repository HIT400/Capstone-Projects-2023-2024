<?php $__env->startSection('panel'); ?>
<div class="row">
    <div class="col-lg-12">
    	<div class="card">
    		<form action="<?php echo e(route('admin.item.store')); ?>" method="post" enctype="multipart/form-data">
    			<?php echo csrf_field(); ?>
                <div class="card-body">
                        <div class="row">
                            <div class="form-group col-md-4">
                                <label><?php echo app('translator')->get('Portrait Image'); ?></label>
                                <div class="image-upload">
                                    <div class="thumb">
                                        <div class="avatar-preview">
                                            <div class="profilePicPreview" style="background-image: url(<?php echo e(getImage('/')); ?>)">
                                                <button type="button" class="remove-image"><i class="fa fa-times"></i></button>
                                            </div>
                                        </div>
                                        <div class="avatar-edit">
                                            <input type="file" class="profilePicUpload" name="portrait" id="profilePicUpload1" accept=".png, .jpg, .jpeg" required>
                                            <label for="profilePicUpload1" class="bg--success"><?php echo app('translator')->get('Upload Portrait Image'); ?></label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group col-md-8">
                                <label><?php echo app('translator')->get('Landscape Image'); ?></label>
                                <div class="image-upload">
                                    <div class="thumb">
                                        <div class="avatar-preview">
                                            <div class="profilePicPreview" style="background-image: url(<?php echo e(getImage('/')); ?>)">
                                                <button type="button" class="remove-image"><i class="fa fa-times"></i></button>
                                            </div>
                                        </div>
                                        <div class="avatar-edit">
                                            <input type="file" class="profilePicUpload" name="landscape" id="profilePicUpload2" accept=".png, .jpg, .jpeg" required>
                                            <label for="profilePicUpload2" class="bg--success"><?php echo app('translator')->get('Upload Landscape Image'); ?></label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="form-group col-md-4">
                                <label><?php echo app('translator')->get('Title'); ?></label>
                                <input type="text" name="title" class="form-control" placeholder="<?php echo app('translator')->get('Title'); ?>" value="<?php echo e(old('title')); ?>">
                            </div>
                            <div class="form-group col-md-4">
                                <label><?php echo app('translator')->get('Item Type'); ?></label>
                                <select class="form-control" name="item_type">
                                    <option value="1"><?php echo app('translator')->get('Single Item'); ?></option>
                                    <option value="2"><?php echo app('translator')->get('Episode Item'); ?></option>
                                    <option value="3"><?php echo app('translator')->get('Trailer Item'); ?></option>
                                </select>
                            </div>
                            <div class="form-group col-md-4 version">
                                <label><?php echo app('translator')->get('Version'); ?></label>
                                <select class="form-control" name="version">
                                    <option value=""><?php echo app('translator')->get('Select One'); ?></option>
                                    <option value="0"><?php echo app('translator')->get('Free'); ?></option>
                                    <option value="1"><?php echo app('translator')->get('Paid'); ?></option>
                                </select>
                            </div>
                        </div>
                        <div class="row">
                            <div class="form-group col-md-6">
                                <label><?php echo app('translator')->get('Category'); ?></label>
                                <select class="form-control" name="category">
                                    <option value=""><?php echo app('translator')->get('Select One'); ?></option>
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($category->id); ?>" data-subcategories="<?php echo e($category->subcategories); ?>"><?php echo e(__($category->name)); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group col-md-6">
                                <label><?php echo app('translator')->get('Sub Category'); ?></label>
                                <select class="form-control" name="sub_category_id">
                                    <option value=""><?php echo app('translator')->get('Select One'); ?></option>
                                </select>
                            </div>
                        </div>
                        <div class="row">
                            <div class="form-group col-md-6">
                                <label><?php echo app('translator')->get('Preview Text'); ?></label>
                                <textarea class="form-control" name="preview_text" rows="5" placeholder="<?php echo app('translator')->get('Preview Text'); ?>"><?php echo e(old('preview_text')); ?></textarea>
                            </div>
                            <div class="form-group col-md-6">
                                <label><?php echo app('translator')->get('Description'); ?></label>
                                <textarea class="form-control" name="description" rows="5" placeholder="<?php echo app('translator')->get('Description'); ?>"><?php echo e(old('description')); ?></textarea>
                            </div>
                        </div>
                        <div class="row">
                            <div class="form-group col-md-4">
                                <label><?php echo app('translator')->get('Director'); ?></label>
                                <input type="text" name="director" class="form-control" placeholder="<?php echo app('translator')->get('Director'); ?>" value="<?php echo e(old('director')); ?>">
                            </div>
                            <div class="form-group col-md-4">
                                <label><?php echo app('translator')->get('Producer'); ?></label>
                                <input type="text" name="producer" class="form-control" placeholder="<?php echo app('translator')->get('Producer'); ?>" value="<?php echo e(old('producer')); ?>">
                            </div>
                            <div class="form-group col-md-4">
                                <label><?php echo app('translator')->get('Ratings'); ?> <small class="text--primary">(<?php echo app('translator')->get('maximum 10 star'); ?>)</small></label>
                                <div class="input-group">
                                    <input type="text" name="ratings" class="form-control" placeholder="Ratings" value="<?php echo e(old('ratings')); ?>">
                                    <span class="input-group-text"><i class="las la-star"></i></span>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="form-group col-md-6">
                                <label class="form-control-label"><?php echo app('translator')->get('Casts'); ?></label>
                                <small class="ml-2 mt-2 text-facebook"><?php echo app('translator')->get('Separate multiple by'); ?> <code>,</code>(<?php echo app('translator')->get('comma'); ?>) <?php echo app('translator')->get('or'); ?> <code><?php echo app('translator')->get('enter'); ?></code> <?php echo app('translator')->get('key'); ?></small>

                                <select name="casts[]" class="form-control select2-auto-tokenize" placeholder="<?php echo app('translator')->get('Add short words which better describe your site'); ?>" multiple="multiple" required>

                                </select>
                            </div>
                            <div class="form-group col-md-6">
                                <label><?php echo app('translator')->get('Tags'); ?></label>
                                <small class="ml-2 mt-2 text-facebook"><?php echo app('translator')->get('Separate multiple by'); ?> <code>,</code>(<?php echo app('translator')->get('comma'); ?>) <?php echo app('translator')->get('or'); ?> <code><?php echo app('translator')->get('enter'); ?></code> <?php echo app('translator')->get('key'); ?></small>

                                <select name="tags[]" class="form-control select2-auto-tokenize" placeholder="<?php echo app('translator')->get('Add short words which better describe your site'); ?>" multiple="multiple" required>

                                </select>
                            </div>
                        </div>
                </div>
                <div class="card-footer">
                    <button type="submit" class="btn btn--primary h-45 w-100"><?php echo app('translator')->get('Submit'); ?></button>
                </div>
    		</form>
    	</div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('breadcrumb-plugins'); ?>
<a href="<?php echo e(route('admin.item.index')); ?>" class="btn btn-outline--primary"><i class="las la-undo"></i> <?php echo app('translator')->get('Back'); ?></a>
<?php $__env->stopPush(); ?>
<?php $__env->startPush('script'); ?>
<script>
(function($){
    "use strict"
    $('[name=category]').change(function(){
        var subcategoryOption = '<option><?php echo app('translator')->get("Select One"); ?></option>';
        var subcategories = $(this).find(':selected').data('subcategories');

        subcategories.forEach(subcategory => {
            subcategoryOption += `<option value="${subcategory.id}">${subcategory.name}</option>`;
        });

        $('[name=sub_category_id]').html(subcategoryOption);
    });

    $('select[name=item_type]').change(function(){
        if ($(this).val() == '1') {
            $('.version').removeClass('d-none');
        }else{
            $('.version').addClass('d-none');
        }
    });
    $('select[name=version]').val('<?php echo e(old('version')); ?>');
    $('select[name=category]').val('<?php echo e(old('category')); ?>');
    $('select[name=sub_category_id]').val('<?php echo e(old('sub_category_id')); ?>');
})(jQuery);
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/sites/31b/a/a24bf68be6/public_html/monah_project/core/resources/views/admin/item/singleCreate.blade.php ENDPATH**/ ?>
<?php
$breadcrumb = getContent('breadcrumb.content',true);
?>
<section class="inner-hero bg_img dark--overlay" data-background="<?php echo e(getImage('assets/images/frontend/breadcrumb/'.@$breadcrumb->data_values->background_image, '1920x500')); ?>">
  <div class="container position-relative">
    <div class="row">
      <div class="col-lg-12">
        <h2 class="text-center "><?php echo e(__($pageTitle)); ?></h2>
        <ul class="page-breadcrumb d-flex justify-content-center">
          <li><a href="<?php echo e(route('home')); ?>" class=""><?php echo app('translator')->get('Home'); ?></a></li>
          <li><?php echo e(__($pageTitle)); ?></li>
        </ul>
      </div>
    </div>
  </div>
</section><?php /**PATH /home/sites/31b/a/a24bf68be6/public_html/monah_project/core/resources/views/templates/labflix/partials/breadcrumb.blade.php ENDPATH**/ ?>
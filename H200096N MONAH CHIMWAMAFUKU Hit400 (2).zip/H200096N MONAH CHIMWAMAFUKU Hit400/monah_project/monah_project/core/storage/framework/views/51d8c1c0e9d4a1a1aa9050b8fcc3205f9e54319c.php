<?php $__env->startSection('panel'); ?>
<div class="row">
    <div class="col-lg-12">
        <div class="card b-radius--10 ">
            <div class="card-body p-0">
                <div class="table-responsive--sm table-responsive">
                    <table class="table table--light style--two">
                        <thead>
                            <tr>
                                <th><?php echo app('translator')->get('Name'); ?></th>
                                <th><?php echo app('translator')->get('Category'); ?></th>
                                <th><?php echo app('translator')->get('Status'); ?></th>
                                <th><?php echo app('translator')->get('Action'); ?></th>
                            </tr>
                        </thead>
                        <tbody class="list">
                            <?php $__empty_1 = true; $__currentLoopData = $subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <?php if($subcategory->category->status == 1): ?>
                            <tr>
                                <td data-label="<?php echo app('translator')->get('Name'); ?>"><?php echo e(__($subcategory->name)); ?></td>
                                <td data-label="<?php echo app('translator')->get('Category'); ?>"><?php echo e(__($subcategory->category->name)); ?></td>
                                <td data-label="<?php echo app('translator')->get('Status'); ?>">
                                    <?php if($subcategory->status == 1): ?>
                                    <span class="badge badge--success font-weight-normal text--small"><?php echo app('translator')->get('Enabled'); ?></span>
                                    <?php else: ?>
                                    <span class="badge badge--danger font-weight-normal text--small"><?php echo app('translator')->get('Disbaled'); ?></span>
                                    <?php endif; ?>
                                </td>
                                <td data-label="<?php echo app('translator')->get('Action'); ?>">
                                    <button class="btn btn-sm btn-outline--primary editBtn" data-name="<?php echo e($subcategory->name); ?>" data-id="<?php echo e($subcategory->id); ?>" data-category_id="<?php echo e($subcategory->category_id); ?>" data-status="<?php echo e($subcategory->status); ?>"><i class="la la-pencil"></i><?php echo app('translator')->get('Edit'); ?></button>
                                </td>
                            </tr>
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td class="text-muted text-center" colspan="100%"><?php echo e(__($emptyMessage)); ?></td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <?php if($subcategories->hasPages()): ?>
            <div class="card-footer py-4">
                <?php echo e(paginateLinks($subcategories)); ?>

            </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Modal -->
<div class="modal fade" id="subCategoryModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel"></h5>
                <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action="<?php echo e(route('admin.subcategory.store')); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label><?php echo app('translator')->get('Sub Category Name'); ?></label>
                        <input type="text" name="name" class="form-control" placeholder="<?php echo app('translator')->get('Sub Category Name'); ?>" required>
                    </div>
                    <div class="form-group">
                        <label><?php echo app('translator')->get('Parent Category Name'); ?></label>
                        <select name="category_id" class="form-control">
                            <option value="">-- <?php echo app('translator')->get('Select One'); ?> --</option>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($category->id); ?>"><?php echo e(__($category->name)); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group statusGroup">
                        <label><?php echo app('translator')->get('Status'); ?></label>
                        <input type="checkbox" data-onstyle="-success" data-offstyle="-danger" data-toggle="toggle" data-on="<?php echo app('translator')->get('Active'); ?>" data-off="<?php echo app('translator')->get('Inactive'); ?>" data-width="100%" name="status">
                    </div>
            </div>
            <div class="modal-footer">
                <button type="submit" class="btn btn--primary w-100 h-45"><?php echo app('translator')->get('Submit'); ?></button>
            </div>
            </form>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>



<?php $__env->startPush('breadcrumb-plugins'); ?>
<button class="btn btn-sm btn-outline--primary addBtn"><i class="las la-plus"></i><?php echo app('translator')->get('Add New'); ?></button>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>

<script>
    (function($){
        "use strict"
        var modal = $('#subCategoryModal');

        $('.addBtn').on('click', function(){
            modal.find('.modal-title').text(`<?php echo app('translator')->get('Add Subcategory'); ?>`);
            modal.find('form').attr('action', `<?php echo e(route('admin.subcategory.store')); ?>`);
            modal.find('.statusGroup').hide();
            modal.modal('show');
        });

        $('.editBtn').on('click',function(){
            var data = $(this).data();
            modal.find('.modal-title').text(`<?php echo app('translator')->get('Update Subcategory'); ?>`);
            modal.find('input[name=name]').val(data.name);
            modal.find('form').attr('action', `<?php echo e(route('admin.subcategory.store', '')); ?>/${data.id}`);
            modal.find('select[name=category_id]').val(`${data.category_id}`);
            modal.find('.statusGroup').show();

            if(data.status == 1){
                modal.find('input[name=status]').bootstrapToggle('on');
            }else{
                modal.find('input[name=status]').bootstrapToggle('off');
            }

            modal.modal('show');
        });
        $('#subCategoryModal').on('hidden.bs.modal', function () {
            $('#subCategoryModal form')[0].reset();
        });
    })(jQuery);
</script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/sites/31b/a/a24bf68be6/public_html/monah_project/core/resources/views/admin/category/subcategory.blade.php ENDPATH**/ ?>
<section class="pb-80 section" data-section="top">
      <div class="container-fluid">
        <div class="row">
          <div class="col-lg-12">
            <div class="section-header">
              <h2 class="section-title"><?php echo app('translator')->get('Latest Items'); ?></h2>
            </div>
          </div>
        </div><!-- row end -->
        <div class="row mb-none-30">
          <?php $__currentLoopData = $recent_added; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="col-xxl-2 col-md-3 col-4 col-xs-6 mb-30">
            <div class="movie-card  <?php if($recent->item_type == 1 && $recent->version == 1 || $recent->item_type == 2): ?> paid <?php endif; ?> " <?php if($recent->item_type == 1 && $recent->version == 0): ?> data-text="<?php echo app('translator')->get('Free'); ?>" <?php elseif($recent->item_type == 3): ?> data-text="<?php echo app('translator')->get('Trailer'); ?>" <?php endif; ?>>
              <div class="movie-card__thumb thumb__2">

                <img src="<?php echo e(getImage(getFilePath('item_portrait').'/'.$recent->image->portrait)); ?>" alt="image">
                <a href="<?php echo e(route('watch',$recent->id)); ?>" class="icon"><i class="fas fa-play"></i></a>
              </div>
            </div><!-- movie-card end -->
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
      </div>
    </section>
    <div class="ad-section pb-80">
      <div class="container">
        <div class="row justify-content-center">
          <div class="col-lg-8">
            <?php echo showAd(); ?>
          </div>
        </div>
      </div>
    </div>
<?php /**PATH /home/sites/31b/a/a24bf68be6/public_html/monah_project/core/resources/views/templates/labflix/sections/recent_added.blade.php ENDPATH**/ ?>
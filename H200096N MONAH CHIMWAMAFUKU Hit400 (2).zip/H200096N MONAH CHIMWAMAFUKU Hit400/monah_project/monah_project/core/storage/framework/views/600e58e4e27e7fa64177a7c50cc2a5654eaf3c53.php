<?php $__env->startSection('panel'); ?>
    <div class="row">
        <div class="col-lg-12">
            <div class="card b-radius--10 ">
                <div class="card-body p-0">
                    <div class="table-responsive--md  table-responsive">
                        <table class="table table--light style--two">
                            <thead>
                            <tr>
                                <th scope="col"><?php echo app('translator')->get('Title'); ?></th>
                                <th scope="col"><?php echo app('translator')->get('Category'); ?></th>
                                <th scope="col"><?php echo app('translator')->get('Sub Category'); ?></th>
                                <th scope="col"><?php echo app('translator')->get('Item Type'); ?></th>
                                <th scope="col"><?php echo app('translator')->get('Status'); ?></th>
                                <th scope="col"><?php echo app('translator')->get('Action'); ?></th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td data-label="<?php echo app('translator')->get('Title'); ?>"><?php echo e($item->title); ?></td>
                                    <td data-label="<?php echo app('translator')->get('Category'); ?>"><?php echo e($item->category->name); ?></td>
                                    <td data-label="<?php echo app('translator')->get('Sub Category'); ?>"><?php echo e(@$item->sub_category->name ?? 'N/A'); ?></td>
                                    <td data-label="<?php echo app('translator')->get('Item Type'); ?>">
                                        <?php if($item->item_type == 1): ?>
                                            <span class="badge badge--success"><?php echo app('translator')->get('Single Item'); ?></span>
                                        <?php elseif($item->item_type == 2): ?>
                                            <span class="badge badge--primary"><?php echo app('translator')->get('Episode Item'); ?></span>
                                        <?php else: ?>
                                            <span class="badge badge--warning"><?php echo app('translator')->get('Trailer'); ?></span>
                                        <?php endif; ?>
                                    </td>
                                    <td data-label="<?php echo app('translator')->get('Status'); ?>">
                                        <?php if($item->status == 1): ?>
                                            <span class="badge badge--success"><?php echo app('translator')->get('Active'); ?></span>
                                        <?php else: ?>
                                            <span class="badge badge--danger"><?php echo app('translator')->get('Deactive'); ?></span>
                                        <?php endif; ?>
                                    </td>
                                    <td data-label="<?php echo app('translator')->get(''); ?>Action">
                                        <a href="<?php echo e(route('admin.item.edit',$item->id)); ?>"
                                           class="btn btn-sm btn-outline--primary">
                                            <i class="la la-pencil"></i><?php echo app('translator')->get('Edit'); ?>
                                        </a>
                                        <?php if($item->item_type == 2): ?>
                                            <a href="<?php echo e(route('admin.item.episodes',$item->id)); ?>"
                                               class="btn btn-sm btn-outline--success">
                                                <i class="las la-list"></i><?php echo app('translator')->get('Episodes'); ?>
                                            </a>
                                        <?php else: ?>
                                            <?php if($item->video): ?>
                                                <a href="<?php echo e(route('admin.item.updateVideo',$item->id)); ?>"
                                                   class="btn btn-sm btn-outline--info">
                                                   <i class="las la-cloud-upload-alt"></i><?php echo app('translator')->get('Update Video'); ?>
                                                </a>
                                            <?php else: ?>
                                                <a href="<?php echo e(route('admin.item.uploadVideo',$item->id)); ?>"
                                                   class="btn btn-sm btn-outline--warning">
                                                   <i class="las la-cloud-upload-alt"></i><?php echo app('translator')->get('Upload Video'); ?>
                                                </a>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="100%" class="text-center"><?php echo app('translator')->get('Item Not Found'); ?></td>
                                </tr>
                            <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="card-footer py-4">
                    <?php echo e(paginateLinks($items)); ?>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('breadcrumb-plugins'); ?>
<div class="d-flex flex-wrap justify-content-end search-group">
    <form action="" method="GET" class="form-inline">
        <div class="input-group justify-content-end">
            <input type="text" name="search" class="form-control bg--white" placeholder="<?php echo app('translator')->get('Title or Category'); ?>" value="<?php echo e(request()->search); ?>">
            <button class="btn btn--primary input-group-text" type="submit"><i class="fa fa-search"></i></button>
        </div>
    </form>
    <a href="<?php echo e(route('admin.item.create')); ?>" class="btn btn-outline--primary ms-2"><i class="la la-plus"></i><?php echo app('translator')->get('Add New'); ?></a>
</div>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/sites/31b/a/a24bf68be6/public_html/monah_project/core/resources/views/admin/item/index.blade.php ENDPATH**/ ?>

<?php $__env->startSection('content'); ?>
    <div class="card-area pt-80 pb-80">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-xl-9">
                    <div class="">
                        <div class="">
                            <ul class="wishlist-card-list">
                            <?php $__empty_1 = true; $__currentLoopData = $histories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $history): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <?php
                                    $path = ($history->item_id == 0)  ? 'episode' : 'item_landscape';
                                    if($history->item_id == 0){
                                        $itemImage = getImage(getFilePath($path) . '/' . $history->episode->image);
                                        $description = @$history->episode->item->description;
                                    }else{
                                        $itemImage = getImage(getFilePath($path) . '/' . $history->item->image->landscape);
                                        $description = @$history->item->description;
                                    }
                                ?>
                                <li class="wishlist-card-list__item">
                                    <div class="wishlist-card-wrapper">
                                        <a href="<?php echo e(route('watch', $history->item_id)); ?>" class="wishlist-card-list__link">
                                            <div class="wishlist-card">
                                                <div class="wishlist-card__thumb">
                                                    <img src="<?php echo e($itemImage); ?>" alt="">
                                                </div>
                                                <div class="wishlist-card__content">
                                                    <h5 class="wishlist-card__title">
                                                        <?php if($history->item_id): ?>
                                                        <?php echo e(__($history->item->title)); ?>

                                                        <?php else: ?>
                                                        <?php echo e(__($history->episode->item->title)); ?> - <?php echo e(__($history->episode->title)); ?>

                                                        <?php endif; ?>
                                                    </h5>
                                                    <p class="wishlist-card__desc"><?php echo e(strLimit($description,60)); ?></p>
                                                </div>
                                            </div>
                                        </a>
                                         <div class="wishlist-card-wrapper__icon">
                                            <button type="button" class="text--base confirmationBtn"  data-action="<?php echo e(route('user.remove.history',$history->id)); ?>" data-question="<?php echo app('translator')->get('Are you sure to remove this item?'); ?>" data-submit_text="btn btn--default btn-md"><i class="las la-times"></i></button>
                                        </div>
                                    </div>
                                </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <li class="text-center text--danger"><?php echo e(__($emptyMessage)); ?></li>
                                <?php endif; ?>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
        <?php if (isset($component)) { $__componentOriginalc51724be1d1b72c3a09523edef6afdd790effb8b = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\ConfirmationModal::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('confirmation-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\ConfirmationModal::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc51724be1d1b72c3a09523edef6afdd790effb8b)): ?>
<?php $component = $__componentOriginalc51724be1d1b72c3a09523edef6afdd790effb8b; ?>
<?php unset($__componentOriginalc51724be1d1b72c3a09523edef6afdd790effb8b); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('style'); ?>
    <style>
        .wishlist-image{
            height: 50px;
            width: 50px;
        }
        .wishlist-card__desc{
            font-size:14px;
        }
        .wishlist-card-wrapper__icon button{
                background: transparent;
                color: red;
                font-size: 20px;
        }
        .wishlist-card-list__item{
            border-bottom: 1px solid #353535;
        }
        .wishlist-card-list__item:last-child{
            border-bottom:none;
        }
    </style>
<?php $__env->stopPush(); ?>


<?php echo $__env->make($activeTemplate . 'layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/sites/31b/a/a24bf68be6/public_html/monah_project/core/resources/views/templates/basic/user/watch/history.blade.php ENDPATH**/ ?>
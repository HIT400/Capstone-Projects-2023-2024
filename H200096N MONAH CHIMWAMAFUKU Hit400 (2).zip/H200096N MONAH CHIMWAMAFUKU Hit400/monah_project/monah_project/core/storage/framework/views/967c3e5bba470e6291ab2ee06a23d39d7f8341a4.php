
<?php $__env->startSection('content'); ?>
    <?php if($user->exp > now()): ?>
        <div class="card-area section--bg ptb-80">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-xl-6">
                        <div class="card custom--card">
                            <div class="card-header d-flex flex-wrap align-items-center justify-content-center">
                                <h4 class="card-title mb-0">
                                    <?php echo app('translator')->get('Current subscription plan is '.@auth()->user()->plan->name); ?>
                                </h4>
                            </div>
                            <div class="card-body">
                                <div class="card-body-content text-center">
                                    <h3 class="title"><?php echo app('translator')->get('Subscription will be expired'); ?></h3>
                                </div>
                                <div class="draw-countdown"
                                     data-year="<?php echo e(\Carbon\Carbon::parse(auth()->user()->exp)->format('Y')); ?>"
                                     data-month="<?php echo e(\Carbon\Carbon::parse(auth()->user()->exp)->format('m')); ?>"
                                     data-day="<?php echo e(\Carbon\Carbon::parse(auth()->user()->exp)->format('d')); ?>"
                                     data-hour="<?php echo e(\Carbon\Carbon::parse(auth()->user()->exp)->format('H')); ?>">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php else: ?>
        <?php if(auth()->user()->deposits->where('status',2)->count() > 0): ?>
            <div class="card-area section--bg pt-80">
                <div class="container">
                    <div class="row justify-content-center">
                        <div class="col-xl-6">
                            <div class="card custom--card">
                                <div class="card-body">
                                    <div class="card-body-content text-center">
                                        <h3 class="title"><?php echo app('translator')->get('Your payment is now in pending, please wait for admin response'); ?></h3>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <section class="plan-section section--bg ptb-80">
            <div class="container">
                <div class="row justify-content-center mb-30-none">

                    <?php $__empty_1 = true; $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 mb-30">
                            <div class="plan-item text-center">
                                <div class="plan-icon">
                                    <?php echo $plan->icon ?>
                                </div>
                                <div class="plan-content">
                                    <span class="sub-title"><?php echo e(__($plan->name)); ?></span>
                                    <h2 class="amount"><?php echo e($general->cur_sym); ?><?php echo e(getAmount($plan->pricing)); ?></h2>
                                    <p><?php echo app('translator')->get('Get '.$plan->duration.' days subscription'); ?></p>
                                    <div class="plan-btn mt-30">
                                        <?php if(auth()->user()->deposits->where('status',2)->count() > 0): ?>
                                            <button class="btn--base w-100" disabled><?php echo app('translator')->get('Subscribe Now'); ?></button>
                                        <?php else: ?>
                                            <button class="btn--base w-100 buyBtn" data-id="<?php echo e($plan->id); ?>"><?php echo app('translator')->get('Subscribe Now'); ?></button>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <?php endif; ?>

                </div>
            </div>
        </section>
    <?php endif; ?>

    <div class="modal fade" id="buyModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
         aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><?php echo app('translator')->get('Subscribe Plan'); ?></h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form action="<?php echo e(route('user.subscribePlan')); ?>" method="post">
                    <?php echo csrf_field(); ?>

                    <input type="hidden" name="id">
                    <div class="modal-body">
                        <h4 class="base--color"><?php echo app('translator')->get('Are you sure to subscribe this plan?'); ?></h4>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn--danger" data-bs-dismiss="modal"><?php echo app('translator')->get('Close'); ?></button>
                        <button type="submit" class="btn btn--default"><?php echo app('translator')->get('Submit'); ?></button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
    <script>
        "use strict";
        $('.buyBtn').click(function () {
            var modal = $('#buyModal');
            modal.find('input[name=id]').val($(this).data('id'));
            modal.modal('show');
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make($activeTemplate.'layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/sites/31b/a/a24bf68be6/public_html/monah_project/core/resources/views/templates/basic/user/dashboard.blade.php ENDPATH**/ ?>
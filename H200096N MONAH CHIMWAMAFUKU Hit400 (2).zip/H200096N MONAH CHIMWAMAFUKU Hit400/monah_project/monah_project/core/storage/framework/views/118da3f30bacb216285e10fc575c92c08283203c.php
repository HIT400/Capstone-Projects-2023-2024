<section class="movie-section section--bg pt-80 pb-80 section" data-section="end">
    <div class="container">
        <div class="row">
            <div class="col-xl-12">
                <div class="section-header">
                    <h2 class="section-title"><?php echo app('translator')->get('Free Zone'); ?></h2>
                </div>
            </div>
        </div>
        <div class="row justify-content-center mb-30-none">

            <?php $__empty_1 = true; $__currentLoopData = $frees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $free): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="col-xl-2 col-lg-3 col-md-4 col-sm-6 col-xs-6 mb-30">
                    <div class="movie-item">
                        <div class="movie-thumb">
                            <img src="<?php echo e(getImage(getFilePath('item_portrait').'/'.$free->image->portrait)); ?>" alt="movie">
                            <div class="movie-thumb-overlay">
                                <a class="video-icon" href="<?php echo e(route('watch', $free->id)); ?>"><i class="fas fa-play"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <?php endif; ?>

        </div>
    </div>
</section>
<?php /**PATH /home/sites/31b/a/a24bf68be6/public_html/monah_project/core/resources/views/templates/basic/sections/free_zone.blade.php ENDPATH**/ ?>
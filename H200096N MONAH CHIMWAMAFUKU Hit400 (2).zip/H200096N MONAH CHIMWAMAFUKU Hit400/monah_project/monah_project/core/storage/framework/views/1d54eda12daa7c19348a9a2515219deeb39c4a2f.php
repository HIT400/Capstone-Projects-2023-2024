<?php $__env->startSection('panel'); ?>
    <div class="row">
        <div class="col-lg-12">
            <div class="card b-radius--10 ">
                <div class="card-body p-0">
                    <div class="table-responsive--md  table-responsive">
                        <table class="table table--light style--two">
                            <thead>
                            <tr>
                                <th scope="col"><?php echo app('translator')->get('Item'); ?></th>
                                <th scope="col"><?php echo app('translator')->get('Status'); ?></th>
                                <th scope="col"><?php echo app('translator')->get('Action'); ?></th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td data-label="<?php echo app('translator')->get('Item'); ?>">
                                        <?php echo e($slider->item->title); ?>

                                    </td>
                                    <td data-label="<?php echo app('translator')->get('Status'); ?>">
                                        <?php if($slider->status == 1): ?>
                                            <span class="badge badge--success"><?php echo app('translator')->get('Enabled'); ?></span>
                                        <?php else: ?>
                                            <span class="badge badge--danger"><?php echo app('translator')->get('Disabled'); ?></span>
                                        <?php endif; ?>
                                    </td>
                                    <td data-label="<?php echo app('translator')->get('Action'); ?>">
                                        <button class="btn btn-sm btn-outline--primary editBtn" data-id="<?php echo e($slider->id); ?>"
                                                data-image="<?php echo e(getImage(getFilePath('slider').'/'.$slider->image, getFileSize('slider'))); ?>" data-status="<?php echo e($slider->status); ?>" data-caption="<?php echo e($slider->caption_show); ?>">
                                            <i class="la la-pencil"></i><?php echo app('translator')->get('Edit'); ?>
                                        </button>
                                        <button class="btn btn-sm btn-outline--danger confirmationBtn" data-id="<?php echo e($slider->id); ?>" data-action="<?php echo e(route('admin.sliders.remove', $slider->id)); ?>" data-question="<?php echo app('translator')->get('Are you sure to delete this slider?'); ?>" data-submit_text="btn btn--primary">
                                            <i class="las la-trash text--shadow"></i><?php echo app('translator')->get('Delete'); ?>
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td class="text-muted text-center" colspan="100%"><?php echo app('translator')->get('Slider Not Found'); ?></td>
                                </tr>
                            <?php endif; ?>

                            </tbody>
                        </table><!-- table end -->
                    </div>
                </div>
                <?php if($sliders->hasPages()): ?>
                <div class="card-footer py-4">
                    <?php echo e($sliders->links('admin.partials.paginate')); ?>

                </div>
                <?php endif; ?>
            </div><!-- card end -->
        </div>
    </div>


    <!-- Slider Modal -->
    <div class="modal fade" id="sliderModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
         aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><?php echo app('translator')->get('Add Slider'); ?></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form action="<?php echo e(route('admin.sliders.add')); ?>" method="post" enctype="multipart/form-data" novalidate>
                    <div class="modal-body">
                        <?php echo csrf_field(); ?>
                        <div class="form-group itemGroup">
                            <label><?php echo app('translator')->get('Select Item'); ?></label>
                            <select name="item" class="form-control item-list select2-basic" required>
                                <option value="">-- <?php echo app('translator')->get('Select One'); ?> --</option>
                                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->id); ?>"><?php echo e($item->title); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <?php
                            if($general->active_template == 'basic'){
                                $slider = 'slider';
                            }else{
                                $slider = 'labflixSlider';
                            }
                        ?>
                        <div class="form-group">
                            <label><?php echo app('translator')->get('Thumbnail Image'); ?></label>
                            <div class="image-upload">
                                <div class="thumb">
                                    <div class="avatar-preview">
                                        <div class="profilePicPreview"
                                             style="background-image: url(<?php echo e(getImage('/', getFileSize($slider))); ?>)">
                                            <button type="button" class="remove-image"><i class="fa fa-times"></i>
                                            </button>
                                        </div>
                                    </div>
                                    <div class="avatar-edit">
                                        <input type="file" class="profilePicUpload" name="image" id="profilePicUpload1"
                                               accept=".png, .jpg, .jpeg" required>
                                        <label for="profilePicUpload1" class="bg--success"><?php echo app('translator')->get('Upload Thumbnail Image'); ?></label>
                                        <small class="mt-2 text-facebook"><?php echo app('translator')->get('Supported files'); ?>: <b><?php echo app('translator')->get('jpeg, jpg, png'); ?></b>. <?php echo app('translator')->get('Image will
                                            be resized into'); ?> <?php echo e(getFileSize($slider)); ?><?php echo app('translator')->get('px'); ?> </small>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php if($general->active_template == 'labflix'): ?>
                        <div class="form-group caption">
                            <label><?php echo app('translator')->get('Caption Status'); ?></label>
                            <input type="checkbox" data-onstyle="-success" data-offstyle="-danger" data-toggle="toggle" data-on="<?php echo app('translator')->get('Enable'); ?>" data-off="<?php echo app('translator')->get('Disable'); ?>" data-width="100%" name="caption_show">
                        </div>
                        <?php endif; ?>
                        <div class="form-group statusGroup">
                            <label><?php echo app('translator')->get('Status'); ?></label>
                            <input type="checkbox" data-onstyle="-success" data-offstyle="-danger" data-toggle="toggle" data-on="<?php echo app('translator')->get('Enable'); ?>" data-off="<?php echo app('translator')->get('Disable'); ?>" data-width="100%" name="status">
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn--primary w-100 h-45"><?php echo app('translator')->get('Submit'); ?></button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <?php if (isset($component)) { $__componentOriginalc51724be1d1b72c3a09523edef6afdd790effb8b = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\ConfirmationModal::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('confirmation-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\ConfirmationModal::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc51724be1d1b72c3a09523edef6afdd790effb8b)): ?>
<?php $component = $__componentOriginalc51724be1d1b72c3a09523edef6afdd790effb8b; ?>
<?php unset($__componentOriginalc51724be1d1b72c3a09523edef6afdd790effb8b); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('breadcrumb-plugins'); ?>
    <button class="btn btn-sm btn-outline--primary addBtn"><i class="las la-plus"></i> <?php echo app('translator')->get('Add New'); ?>
    </button>
<?php $__env->stopPush(); ?>
<?php $__env->startPush('script'); ?>
    <script>
        

        var modal = $('#sliderModal');
        var defautlImage = `<?php echo e(getImage(getFilePath('slider'), getFileSize('slider'))); ?>`;
        $('.addBtn').click(function () {
            modal.find('.modal-title').text(`<?php echo app('translator')->get('Add Slider'); ?>`);
            modal.find('form').attr('action', `<?php echo e(route('admin.sliders.add')); ?>`);
            modal.find('.itemGroup').show();
            modal.find('.statusGroup').hide();
            modal.find('input[name=caption_show]').bootstrapToggle('off');
            modal.modal('show');
            $(".item-list").select2({
                ajax: {
                url: "<?php echo e(route('admin.item.list')); ?>",
                type: "get",
                dataType: 'json',
                delay: 1000,
                data: function (params) {
                    return {
                        search: params.term,
                        page: params.page,
                        rows: 5,
                    };
                },
                processResults: function (response, params) {
                    params.page = params.page || 1;
                    return {
                        results: response,
                        pagination: {
                            more: params.page < response.length
                        }
                    };
                },
                cache: false
            },
                
            dropdownParent: modal });
        });
        $('.editBtn').click(function () {
            modal.find('.modal-title').text(`<?php echo app('translator')->get('Update Slider'); ?>`);
            modal.find('.itemGroup').hide();
            modal.find('.profilePicPreview').attr('style', `background-image: url(${$(this).data('image')})`);
            modal.find('form').attr('action', `<?php echo e(route('admin.sliders.update', '')); ?>/${$(this).data('id')}`);

            modal.find('.statusGroup').show();
            var caption = $(this).data('caption');
            var status = $(this).data('status');
            if(caption == 1){
                modal.find('input[name=caption_show]').bootstrapToggle('on');
            }else{
                modal.find('input[name=caption_show]').bootstrapToggle('off');
            }
            if(status == 1){
                modal.find('input[name=status]').bootstrapToggle('on');
            }else{
                modal.find('input[name=status]').bootstrapToggle('off');
            }
            modal.modal('show');
        });
        
        modal.on('hidden.bs.modal', function () {
            modal.find('.profilePicPreview').attr('style', `background-image: url(${defautlImage})`);
            $('#sliderModal form')[0].reset();
        });

    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/sites/31b/a/a24bf68be6/public_html/monah_project/core/resources/views/admin/sliders/index.blade.php ENDPATH**/ ?>
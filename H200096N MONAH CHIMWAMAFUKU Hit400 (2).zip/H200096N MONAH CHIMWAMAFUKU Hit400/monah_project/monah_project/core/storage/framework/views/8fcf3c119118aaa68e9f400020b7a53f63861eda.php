<?php $__env->startSection('panel'); ?>
<div class="row">
    <div class="col-lg-12">
    	<div class="card b-radius--10 ">
    		<div class="card-body p-0">
    			<div class="table-responsive--md  table-responsive">
    				<table class="table table--light style--two">
    					<thead>
    						<tr>
    							<th scope="col"><?php echo app('translator')->get('Title'); ?></th>
    							<th scope="col"><?php echo app('translator')->get('Status'); ?></th>
                                <th scope="col"><?php echo app('translator')->get('Version'); ?></th>
    							<th scope="col"><?php echo app('translator')->get('Action'); ?></th>
    						</tr>
    					</thead>
    					<tbody>
    						<?php $__empty_1 = true; $__currentLoopData = $episodes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $episode): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    						<tr>
    							<td data-label="<?php echo app('translator')->get('Title'); ?>"><?php echo e(__($episode->title)); ?></td>
    							<td data-label="<?php echo app('translator')->get('Status'); ?>">
    								<?php if($episode->status == 1): ?>
    								<span class="badge badge--success"><?php echo app('translator')->get('Active'); ?></span>
    								<?php else: ?>
    								<span class="badge badge--danger"><?php echo app('translator')->get('Inactive'); ?></span>
    								<?php endif; ?>
    							</td>
                                <td data-label="Version">
                                    <?php if($episode->version == 0): ?>
                                    <span class="badge badge--success"><?php echo app('translator')->get('Free'); ?></span>
                                    <?php else: ?>
                                    <span class="badge badge--primary"><?php echo app('translator')->get('Paid'); ?></span>
                                    <?php endif; ?>
                                </td>
    							<td data-label="<?php echo app('translator')->get('Action'); ?>">
    								<button class="btn btn-sm btn-outline--primary editBtn" data-title="<?php echo e($episode->title); ?>" data-version="<?php echo e($episode->version); ?>" data-image="<?php echo e(getImage(getFilePath('episode').'/'.$episode->image)); ?>" data-episode_id="<?php echo e($episode->id); ?>" data-status="<?php echo e($episode->status); ?>" data-toggle="tooltip" title="" data-original-title="Edit">
    									<i class="la la-pencil"></i><?php echo app('translator')->get('Edit'); ?>
    								</button>
    								<?php if($episode->video): ?>
    								<a href="<?php echo e(route('admin.item.episode.updateVideo',$episode->id)); ?>" class="btn btn-sm btn-outline--info">
    									<i class="la la-cloud-upload-alt"></i><?php echo app('translator')->get('Update Video'); ?>
    								</a>
    								<?php else: ?>
    								<a href="<?php echo e(route('admin.item.episode.addVideo',$episode->id)); ?>" class="btn btn-sm btn-outline--warning">
    									<i class="la la-cloud-upload-alt"></i><?php echo app('translator')->get('Upload Video'); ?>
    								</a>
    								<?php endif; ?>
    							</td>
    						</tr>
    						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    						<tr>
    							<td colspan="100%" class="text-center"><?php echo e(__($emptyMessage)); ?></td>
    						</tr>
    						<?php endif; ?>
    					</tbody>
    				</table>
    			</div>
    		</div>
    		<div class="card-footer py-4">
    			<?php echo e($episodes->links('admin.partials.paginate')); ?>

    		</div>
    	</div>
    </div>
</div>

<!-- Modal -->
<div class="modal fade" id="episodeModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title"><?php echo app('translator')->get('Add New Episode'); ?></h5>
        <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form action="<?php echo e(route('admin.item.addEpisode',$item->id)); ?>" method="post" enctype="multipart/form-data">
      	<?php echo csrf_field(); ?>
	      <div class="modal-body">
	        <div class="form-group">
	        	<label><?php echo app('translator')->get('Thumbnail Image'); ?></label>
	        	<div class="image-upload">
	        		<div class="thumb">
	        			<div class="avatar-preview">
	        				<div class="profilePicPreview" style="background-image: url(<?php echo e(getImage('')); ?>)">
	        					<button type="button" class="remove-image"><i class="fa fa-times"></i></button>
	        				</div>
	        			</div>
	        			<div class="avatar-edit">
	        				<input type="file" class="profilePicUpload" name="image" id="profilePicUpload1" accept=".png, .jpg, .jpeg">
	        				<label for="profilePicUpload1" class="bg--success"><?php echo app('translator')->get('Upload Thumbnail Image'); ?></label>
	        			</div>
	        		</div>
	        	</div>
	        </div>
	        <div class="form-group">
	        	<label><?php echo app('translator')->get('Video Title'); ?></label>
	        	<input type="text" name="title" class="form-control" required>
	        </div>
            <div class="form-group">
                <label><?php echo app('translator')->get('Version'); ?></label>
                <select class="form-control" name="version" required>
                    <option value="0"><?php echo app('translator')->get('Free'); ?></option>
                    <option value="1"><?php echo app('translator')->get('Paid'); ?></option>
                </select>
            </div>
			<div class="form-group statusGroup">
				<label><?php echo app('translator')->get('Status'); ?></label>
				<input type="checkbox" data-onstyle="-success" data-offstyle="-danger" data-toggle="toggle" data-on="<?php echo app('translator')->get('Active'); ?>" data-off="<?php echo app('translator')->get('Inactive'); ?>" data-width="100%" name="status">
			</div>
	      </div>
	      <div class="modal-footer">
	        <button type="submit" class="btn btn--primary w-100 h-45"><?php echo app('translator')->get('Submit'); ?></button>
	      </div>
      </form>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('breadcrumb-plugins'); ?>
<button class="btn btn-sm btn-outline--primary addBtn"><i class="las la-plus"></i><?php echo app('translator')->get('Add New Episode'); ?></button>
<?php $__env->stopPush(); ?>
<?php $__env->startPush('script'); ?>
<script>
    (function($){
        "use strict"
		var modal = $('#episodeModal');

    	$('.addBtn').click(function(){
			modal.find('form').attr('action', `<?php echo e(route('admin.item.addEpisode', $item->id)); ?>`);
			modal.find('.statusGroup').hide();
    		modal.modal('show');
    	});

    	$('.editBtn').click(function(){
			let data = $(this).data();
    		modal.find('input[name=title]').val(data.title);
    		modal.find('.profilePicPreview').attr('style',`background-image:url(${data.image})`);
            modal.find('select').val(data.version);
			modal.find('.statusGroup').show();

			if(data.status == 1){
				modal.find('input[name=status]').bootstrapToggle('on');
			}else{
				modal.find('input[name=status]').bootstrapToggle('off');
			}

    		modal.find('form').attr('action', `<?php echo e(route('admin.item.updateEpisode','')); ?>/${data.episode_id}`);

    		modal.modal('show');
    	});

		modal.on('hidden.bs.modal', function () {
            modal.find('form')[0].reset();
        });

    })(jQuery);
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/sites/31b/a/a24bf68be6/public_html/monah_project/core/resources/views/admin/item/episode/index.blade.php ENDPATH**/ ?>
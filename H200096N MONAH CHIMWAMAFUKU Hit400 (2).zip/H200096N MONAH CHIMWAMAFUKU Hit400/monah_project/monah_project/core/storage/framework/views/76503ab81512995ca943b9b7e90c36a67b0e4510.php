<!-- header-section start  -->

<header class="header">
    <div class="header__bottom">
        <div class="container-fluid p-0">
            <nav class="navbar navbar-expand-xl p-0 align-items-center">
                <a class="site-logo site-title" href="<?php echo e(route('home')); ?>"><img src="<?php echo e(getImage(getFilePath('logoIcon') .'/logo.png')); ?>" alt="site-logo"><span class="logo-icon"><i class="flaticon-fire"></i></span></a>
                <button class="navbar-toggler ml-auto" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="menu-toggle"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav main-menu mx-auto ms-xl-5">
                        <li><a href="<?php echo e(route('home')); ?>"><?php echo app('translator')->get('Home'); ?></a></li>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($category->subcategories->where('status',1)->count() > 0): ?>
                            <li class="menu_has_children">
                                <a href="<?php echo e(route('category',$category->id)); ?>"><?php echo e(__($category->name)); ?></a>
                                <ul class="sub-menu">
                                    <?php $__currentLoopData = $category->subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><a href="<?php echo e(route('subCategory',$subcategory->id)); ?>"><?php echo e(__($subcategory->name)); ?></a></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </li>
                            <?php else: ?>
                            <li><a href="<?php echo e(route('category',$category->id)); ?>"><?php echo e(__($category->name)); ?></a></li>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <li><a href="<?php echo e(route('live.tv')); ?>"><?php echo app('translator')->get('Live TV'); ?></a></li>
                        <?php if(auth()->guard()->guest()): ?>
                        <li><a href="<?php echo e(route('contact')); ?>"><?php echo app('translator')->get('Contact'); ?></a></li>
                        <?php else: ?> 
                        <li><a href="<?php echo e(route('user.deposit.history')); ?>"><?php echo app('translator')->get('Payments'); ?></a></li>
                        <li><a href="<?php echo e(route('user.wishlist')); ?>"><?php echo app('translator')->get('My Wishlist'); ?></a></li>
                        <li><a href="<?php echo e(route('user.watch.history')); ?>"><?php echo app('translator')->get('Watch History'); ?></a></li>
                        <li class="menu_has_children">
                            <a href="javascript:void(0)"><?php echo app('translator')->get('Support Ticket'); ?></a>
                            <ul class="sub-menu">
                                <li><a href="<?php echo e(route('ticket.open')); ?>"><?php echo app('translator')->get('Create New'); ?></a></li>
                                <li><a href="<?php echo e(route('ticket')); ?>"><?php echo app('translator')->get('My Ticket'); ?></a></li>
                            </ul>
                        </li>
                        <?php endif; ?>
                    </ul>
                    <div class="nav-right ml-auto d-flex flex-wrap gap-4">
                        <button class="nav-right__search-btn"><i class="fas fa-search"></i></button>
                        <?php if(auth()->guard()->guest()): ?>
                        <a href="<?php echo e(route('user.login')); ?>"><i class="las la-sign-in-alt"></i> <?php echo app('translator')->get('Login'); ?></a>
                        <a href="<?php echo e(route('user.register')); ?>"><i class="las la-user-plus"></i> <?php echo app('translator')->get('Registration'); ?></a>
                        <?php else: ?>
                        <div class="dropdown">
                            <button type="button" class="" data-bs-toggle="dropdown" data-display="static" aria-haspopup="true" aria-expanded="false"><i class="las la-user-plus"></i> <?php echo app('translator')->get('Account'); ?></button>
                            <div class="dropdown-menu dropdown-menu--sm p-0 border-0 box--shadow1 dropdown-menu-right">
                                <a href="<?php echo e(route('user.home')); ?>" class="dropdown-menu__item d-flex align-items-center px-3 py-2">
                                    <i class="dropdown-menu__icon las la-home"></i>
                                    <span class="dropdown-menu__caption"><?php echo app('translator')->get('Dashboard'); ?></span>
                                </a>
                                <a href="<?php echo e(route('user.profile.setting')); ?>" class="dropdown-menu__item d-flex align-items-center px-3 py-2">
                                    <i class="dropdown-menu__icon las la-user-circle"></i>
                                    <span class="dropdown-menu__caption"><?php echo app('translator')->get('Profile'); ?></span>
                                </a>

                                <a href="<?php echo e(route('user.change.password')); ?>" class="dropdown-menu__item d-flex align-items-center px-3 py-2">
                                    <i class="dropdown-menu__icon las la-key"></i>
                                    <span class="dropdown-menu__caption"><?php echo app('translator')->get('Password'); ?></span>
                                </a>


                                <a href="<?php echo e(route('user.logout')); ?>" class="dropdown-menu__item d-flex align-items-center px-3 py-2">
                                    <i class="dropdown-menu__icon las la-sign-out-alt"></i>
                                    <span class="dropdown-menu__caption"><?php echo app('translator')->get('Logout'); ?></span>
                                </a>
                            </div>
                        </div>
                        <?php endif; ?>
                        <select class="language-select langSel" id="langSel">
                            <?php $__currentLoopData = $language; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($lang->code); ?>" <?php if(Session::get('lang') === $lang->code): ?> selected  <?php endif; ?>><?php echo e(__($lang->name)); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
            </nav>
        </div>
    </div>
</header>
<!-- header-section end  -->
<!-- header-search-area start -->
<div class="header-search-area">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <form action="<?php echo e(route('search')); ?>" class="header-search-form">
                    <input type="text" name="search" placeholder="<?php echo app('translator')->get('Search here'); ?>....">
                    <button type="submit"><i class="fas fa-search"></i></button>
                </form>
            </div>
        </div>
    </div>
</div>
<!-- header-search-area end -->
<!-- header-section end  --><?php /**PATH /home/sites/31b/a/a24bf68be6/public_html/monah_project/core/resources/views/templates/labflix/partials/header.blade.php ENDPATH**/ ?>
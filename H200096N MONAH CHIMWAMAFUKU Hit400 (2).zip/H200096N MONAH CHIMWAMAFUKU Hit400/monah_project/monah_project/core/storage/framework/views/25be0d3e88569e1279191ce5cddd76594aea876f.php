<header class="header-section">
    <div class="header">
        <div class="header-bottom-area">
            <div class="container">
                <div class="header-menu-content">
                    <nav class="navbar navbar-expand-lg p-0">
                        <a class="site-logo site-title mr-auto" href="<?php echo e(route('home')); ?>"><img src="<?php echo e(asset('assets/images/logoIcon/logo.png')); ?>" alt="site-logo"></a>
                        <div class="search-bar d-block d-lg-none">
                            <a href="#0"><i class="fas fa-search"></i></a>
                            <div class="header-top-search-area">
                                <form class="header-search-form" action="<?php echo e(route('search')); ?>">
                                    <input type="search" name="search" placeholder="<?php echo app('translator')->get('Search here'); ?>...">
                                    <button class="header-search-btn" type="submit"><i class="fas fa-search"></i></button>
                                </form>
                            </div>
                        </div>

                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                    data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                        aria-expanded="false" aria-label="Toggle navigation">
                            <span class="fas fa-bars"></span>
                     </button>

                        <div class="collapse navbar-collapse" id="navbarSupportedContent">
                            <ul class="navbar-nav main-menu ms-auto me-auto">
                                <li class="nav-item"><a class="nav-link" aria-current="page" href="<?php echo e(route('home')); ?>"><?php echo app('translator')->get('Home'); ?></a></li>
                                <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <?php if($category->subcategories->count()): ?>
                                        <li><a class="nav-link dropdown-toggle category-nav" href="<?php echo e(route('category',$category->id)); ?>"><?php echo e(__($category->name)); ?> <span class="menu__icon"><i class="fas fa-caret-down"></i></span></a> 
                                            <ul class="sub-menu">
                                                <?php $__empty_2 = true; $__currentLoopData = $category->subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                                                    <li><a href="<?php echo e(route('subCategory',$subcategory->id)); ?>"><?php echo e(__($subcategory->name)); ?></a></li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                                                <?php endif; ?>
                                            </ul>
                                        </li>
                                    <?php else: ?>
                                        <li><a href="<?php echo e(route('category',$category->id)); ?>"><?php echo e(__($category->name)); ?></a></li>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <?php endif; ?>
                                <li><a href="<?php echo e(route('live.tv')); ?>"><?php echo app('translator')->get('Live TV'); ?></a></li>
                            </ul>
                            <div class="search-bar d-none d-lg-block">
                                <a href="#0"><i class="fas fa-search"></i></a>
                                <div class="header-top-search-area">
                                    <form class="header-search-form" action="<?php echo e(route('search')); ?>">
                                        <input type="search" name="search" placeholder="<?php echo app('translator')->get('Search here'); ?>...">
                                        <button class="header-search-btn" type="submit"><i class="fas fa-search"></i></button>
                                    </form>
                                </div>
                            </div>
                            <div class="header-bottom-right">
                                <div class="language-select-area">
                                    <select class="language-select langSel" id="langSel">
                                        <?php $__currentLoopData = $language; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($lang->code); ?>" <?php if(Session::get('lang') === $lang->code): ?> selected  <?php endif; ?>><?php echo e(__($lang->code)); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="header-action">
                                <?php if(auth()->guard()->check()): ?>
                                    <a href="<?php echo e(route('user.home')); ?>" class="btn--base"><i class="las la-home"></i><?php echo app('translator')->get('Dashboard'); ?></a>
                                <?php else: ?>
                                    <a href="<?php echo e(route('user.register')); ?>" class="btn--base"><i class="las la-user-circle"></i><?php echo app('translator')->get('Register'); ?></a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</header><?php /**PATH /home/sites/31b/a/a24bf68be6/public_html/monah_project/core/resources/views/templates/basic/partials/frontend_header.blade.php ENDPATH**/ ?>
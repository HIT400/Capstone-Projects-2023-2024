<?php $__env->startSection('content'); ?>
    <section class="movie-section section--bg ptb-80">
        <div class="container">
            <div class="row justify-content-center mb-30-none ajaxLoad">
                <?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php if($loop->last): ?>
                        <span class="data_id d-none" data-id="<?php echo e($item->id); ?>"></span>
                        <span class="category_id d-none" data-category_id="<?php echo e(@$category->id); ?>"></span>
                        <span class="subcategory_id d-none" data-subcategory_id="<?php echo e(@$subcategory->id); ?>"></span>
                        <span class="search d-none" data-search="<?php echo e(@$search); ?>"></span>
                    <?php endif; ?>
                    <div class="col-xl-2 col-lg-3 col-md-4 col-sm-6 col-xs-6 mb-30">
                        <div class="movie-item">
                            <div class="movie-thumb">
                                <img src="<?php echo e(getImage(getFilePath('item_portrait').'/'.$item->image->portrait)); ?>" alt="movie">
                                <?php if($item->item_type == 1 && $item->version == 0): ?>
                                    <span class="movie-badge"><?php echo app('translator')->get('Free'); ?></span>
                                <?php elseif($item->item_type == 3): ?>
                                    <span class="movie-badge"><?php echo app('translator')->get('Trailer'); ?></span>
                                <?php endif; ?>
                                <div class="movie-thumb-overlay">
                                    <a class="video-icon" href="<?php echo e(route('watch',$item->id)); ?>"><i class="fas fa-play"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>  
                <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12 col-xs-12 mb-30">
                    <img src="<?php echo e(asset($activeTemplateTrue.'images/no-results.png')); ?>" alt="">
                </div>

                <?php endif; ?>
            </div>
        </div>
    </section>
    <div class="custom_loading"></div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
    <script>
        "use strict"
        var send = 0;
        $(window).scroll(function () {
            if ($(window).scrollTop() + $(window).height() > $(document).height() - 60) {
                if ($('.ajaxLoad').hasClass('loaded')) {
                    $('.custom_loading').removeClass('loader-area');
                    return false;
                }
                $('.custom_loading').addClass('loader-area');
                setTimeout(function () {
                    if (send == 0) {
                        send = 1;
                        var url = '<?php echo e(route('loadmore.load_data')); ?>';
                        var id = $('.data_id').last().data('id');
                        var category_id = $('.category_id').last().data('category_id');
                        var subcategory_id = $('.subcategory_id').last().data('subcategory_id');
                        var search = $('.search').last().data('search');
                        var data = {id: id, category_id: category_id, subcategory_id: subcategory_id, search: search};
                        $.get(url, data, function (response) {
                            if (response == 'end') {
                                $('.custom_loading').removeClass('loader-area');
                                $('.footer').removeClass('d-none');
                                $('.ajaxLoad').addClass('loaded');
                                return false;
                            }
                            $('.custom_loading').removeClass('loader-area');
                            $('.sections').append(response);
                            $('.ajaxLoad').append(response);
                            send = 0;
                        });
                    }
                }, 1000);
            }
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make($activeTemplate.'layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/sites/31b/a/a24bf68be6/public_html/monah_project/core/resources/views/templates/basic/items.blade.php ENDPATH**/ ?>
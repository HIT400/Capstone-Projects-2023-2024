
<?php $__env->startSection('content'); ?>
    <div class="card-area section--bg ptb-80">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-xl-10">
                     <table class="custom-table">
                        <thead>
                        <tr>
                            <th scope="col"><?php echo app('translator')->get('Transaction ID'); ?></th>
                            <th scope="col"><?php echo app('translator')->get('Plan Name'); ?></th>
                            <th scope="col"><?php echo app('translator')->get('Gateway'); ?></th>
                            <th scope="col"><?php echo app('translator')->get('Amount'); ?></th>
                            <th scope="col"><?php echo app('translator')->get('Status'); ?></th>
                            <th scope="col"><?php echo app('translator')->get('Time'); ?></th>
                            <th scope="col"> <?php echo app('translator')->get('MORE'); ?></th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $deposits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td data-label="#<?php echo app('translator')->get('Trx'); ?>"><?php echo e($data->trx); ?></td>
                                <td data-label="<?php echo app('translator')->get('Plan Name'); ?>"><?php echo e(__(@$data->subscription->plan->name)); ?></td>
                                <td data-label="<?php echo app('translator')->get('Gateway'); ?>"><?php echo e(__($data->gateway->name)); ?></td>
                                <td data-label="<?php echo app('translator')->get('Amount'); ?>">
                                    <strong><?php echo e(getAmount($data->amount)); ?> <?php echo e($general->cur_text); ?></strong>
                                </td>
                                <td data-label="<?php echo app('translator')->get('Status'); ?>">
                                    <?php if($data->status == 1): ?>
                                        <span class="badge badge--success"><?php echo app('translator')->get('Complete'); ?></span>
                                    <?php elseif($data->status == 2): ?>
                                        <span class="badge badge--warning"><?php echo app('translator')->get('Pending'); ?></span>
                                    <?php elseif($data->status == 3): ?>
                                        <span class="badge badge--danger"><?php echo app('translator')->get('Cancel'); ?></span>
                                    <?php endif; ?>

                                    <?php if($data->admin_feedback != null): ?>
                                        <button class="btn--info btn-rounded  badge detailBtn" data-admin_feedback="<?php echo e($data->admin_feedback); ?>"><i class="fa fa-info"></i></button>
                                    <?php endif; ?>


                                </td>
                                <td data-label="<?php echo app('translator')->get('Time'); ?>">
                                    <i class="fa fa-calendar"></i> <?php echo e(showDateTime($data->created_at)); ?>

                                </td>


                                <?php
                                    $details = ($data->detail != null) ? json_encode($data->detail) : null;
                                ?>

                                <td data-label="<?php echo app('translator')->get('Details'); ?>">
                                    <a href="javascript:void(0)" class="btn btn--default btn-sm approveBtn"
                                       data-info="<?php echo e($details); ?>"
                                       data-id="<?php echo e($data->id); ?>"
                                       data-amount="<?php echo e(getAmount($data->amount)); ?> <?php echo e($general->cur_text); ?>"
                                       data-charge="<?php echo e(getAmount($data->charge)); ?> <?php echo e($general->cur_text); ?>"
                                       data-after_charge="<?php echo e(getAmount($data->amount + $data->charge)); ?> <?php echo e($general->cur_text); ?>"
                                       data-rate="<?php echo e(getAmount($data->rate)); ?> <?php echo e($data->method_currency); ?>"
                                       data-payable="<?php echo e(getAmount($data->final_amo)); ?> <?php echo e($data->method_currency); ?>">
                                        <i class="fa fa-desktop"></i>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="100" class="data-not-found">
                                  <div class="data-not-found__text text-center">
                                    <h6 class="empty-table__text mt-1"><?php echo e(__($emptyMessage)); ?> </h6>
                                  </div>
                                </td>
                            </tr>
                        <?php endif; ?>
                        </tbody>
                    </table>

                    <?php echo e($deposits->links()); ?>

                </div>
            </div>
        </div>
    </div>
  
    
    <div id="approveModal" class="modal fade" tabindex="-1" role="dialog">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><?php echo app('translator')->get('Details'); ?></h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <ul class="list-group list-items">
                        <li class="list-group-item d-flex justify-content-between"><?php echo app('translator')->get('Amount'); ?> : <span class="withdraw-amount "></span>
                        </li>
                        <li class="list-group-item d-flex justify-content-between"><?php echo app('translator')->get('Charge'); ?> : <span class="withdraw-charge "></span>
                        </li>
                        <li class="list-group-item d-flex justify-content-between"><?php echo app('translator')->get('After Charge'); ?> : <span
                                class="withdraw-after_charge"></span></li>
                        <li class="list-group-item d-flex justify-content-between"><?php echo app('translator')->get('Conversion Rate'); ?> : <span
                                class="withdraw-rate"></span></li>
                        <li class="list-group-item d-flex justify-content-between"><?php echo app('translator')->get('Payable Amount'); ?> : <span
                                class="withdraw-payable"></span></li>
                    </ul>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn--danger w-100" data-bs-dismiss="modal"><?php echo app('translator')->get('Close'); ?></button>
                </div>
            </div>
        </div>
    </div>

    
    <div id="detailModal" class="modal fade" tabindex="-1" role="dialog">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><?php echo app('translator')->get('Details'); ?></h5>
                    <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="withdraw-detail"></div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn--secondary" data-bs-dismiss="modal"><?php echo app('translator')->get('Close'); ?></button>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('script'); ?>
    <script>
        (function ($) {
            "use strict";

            $('.approveBtn').on('click', function () {
                var modal = $('#approveModal');
                var data = $(this).data();
                modal.find('.withdraw-amount').text(data.amount);
                modal.find('.withdraw-charge').text(data.charge);
                modal.find('.withdraw-after_charge').text(data.after_charge);
                modal.find('.withdraw-rate').text(data.rate);
                modal.find('.withdraw-payable').text(data.payable);
                modal.modal('show');
            });

            $('.detailBtn').on('click', function () {
                var modal = $('#detailModal');
                var feedback = $(this).data('admin_feedback');
                modal.find('.withdraw-detail').html(`<p> ${feedback} </p>`);
                modal.modal('show');
            });
        })(jQuery);
    </script>
<?php $__env->stopPush(); ?>


<?php echo $__env->make($activeTemplate.'layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/sites/31b/a/a24bf68be6/public_html/monah_project/core/resources/views/templates/basic/user/deposit_history.blade.php ENDPATH**/ ?>